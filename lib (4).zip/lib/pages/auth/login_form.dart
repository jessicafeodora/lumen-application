import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:lumen_application/widgets/primary_button.dart';
import 'package:lumen_application/widgets/hover_link.dart';

class LoginForm extends StatefulWidget {
  final VoidCallback onGoRegister;
  const LoginForm({super.key, required this.onGoRegister});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass = TextEditingController();

  bool _remember = true;
  bool _showPass = false;
  bool _loading = false;
  String _error = '';

  bool get _validBasic {
    final e = _email.text.trim().toLowerCase();
    final p = _pass.text;
    return e.endsWith('@gmail.com') && p.length >= 6;
  }

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _ensureUserProfile(User user) async {
    final db = FirebaseDatabase.instance.ref();
    final userRef = db.child('users/${user.uid}');
    final snap = await userRef.get();

    final now = ServerValue.timestamp;
    if (!snap.exists) {
      await userRef.set({
        'uid': user.uid,
        'email': user.email,
        'createdAt': now,
        'lastLoginAt': now,
      });
    } else {
      await userRef.update({'lastLoginAt': now});
    }
  }

  Future<void> _submit() async {
    setState(() => _error = '');
    final ok = _formKey.currentState?.validate() ?? false;
    if (!ok) return;

    setState(() => _loading = true);
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim().toLowerCase(),
        password: _pass.text,
      );
      final user = cred.user;
      if (user != null) await _ensureUserProfile(user);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        setState(() => _error = 'Account not found.');
      } else if (e.code == 'wrong-password') {
        setState(() => _error = 'Wrong password.');
      } else {
        setState(() => _error = 'Login failed.');
      }
    } catch (_) {
      setState(() => _error = 'Login failed.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Sign in',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w900,
            letterSpacing: -0.3,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Use your account to continue.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: scheme.onSurface.withOpacity(0.62),
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),

        Form(
          key: _formKey,
          onChanged: () => setState(() {}),
          child: Column(
            children: [
              _Field(
                label: 'Email (@gmail.com)',
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                validator: (v) {
                  final s = (v ?? '').trim().toLowerCase();
                  if (s.isEmpty) return 'Email is required';
                  if (!s.endsWith('@gmail.com')) return 'Use a @gmail.com email';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              _Field(
                label: 'Password',
                controller: _pass,
                obscureText: !_showPass,
                validator: (v) {
                  final s = v ?? '';
                  if (s.isEmpty) return 'Password is required';
                  if (s.length < 6) return 'Password must be at least 6 characters';
                  return null;
                },
                trailing: IconButton(
                  tooltip: _showPass ? 'Hide password' : 'Show password',
                  onPressed: () => setState(() => _showPass = !_showPass),
                  icon: Icon(
                    _showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              Row(
                children: [
                  Checkbox(
                    value: _remember,
                    onChanged: (v) => setState(() => _remember = v ?? true),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                  ),
                  Text(
                    'Remember me',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: scheme.onSurface.withOpacity(0.70),
                    ),
                  ),
                  const Spacer(),
                  HoverLink(
                    text: 'Forgot password?',
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Forgot password is not wired yet.')),
                      );
                    },
                  ),
                ],
              ),

              if (_error.isNotEmpty) ...[
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    _error,
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: scheme.error,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 10),

              PrimaryButton(
                text: 'Sign in',
                loading: _loading,
                enabled: _validBasic && !_loading,
                onTap: _submit,
              ),

              const SizedBox(height: 14),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an account? ",
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: scheme.onSurface.withOpacity(0.62),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  HoverLink(
                    text: 'Register',
                    onTap: widget.onGoRegister,
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final bool obscureText;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final Widget? trailing;

  const _Field({
    required this.label,
    required this.controller,
    this.obscureText = false,
    this.keyboardType,
    this.validator,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      validator: validator,
      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
        fontWeight: FontWeight.w600,
      ),
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: scheme.surface.withOpacity(0.55),
        suffixIcon: trailing,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: scheme.outline.withOpacity(0.25)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: scheme.outline.withOpacity(0.25)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: scheme.primary.withOpacity(0.70), width: 1.2),
        ),
      ),
    );
  }
}
