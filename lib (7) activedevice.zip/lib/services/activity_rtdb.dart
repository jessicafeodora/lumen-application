import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'rtdb_service.dart';

class ActivityEntry {
  final String id;
  final String action;
  final String actor; // "app" | "device"
  final String? deviceId;
  final DateTime createdAt;

  ActivityEntry({
    required this.id,
    required this.action,
    required this.actor,
    required this.createdAt,
    this.deviceId,
  });

  static ActivityEntry fromMap(String id, Map data) {
    final createdRaw = data['createdAt'];
    final createdAt = createdRaw is int
        ? DateTime.fromMillisecondsSinceEpoch(createdRaw)
        : DateTime.now();

    return ActivityEntry(
      id: id,
      action: (data['action'] ?? '').toString(),
      actor: (data['actor'] ?? 'app').toString(),
      deviceId: data['deviceId']?.toString(),
      createdAt: createdAt,
    );
  }
}

class ActivityRTDB {
  ActivityRTDB._();

  static DatabaseReference _userRoot(String uid) =>
      RTDBService.globalRef('users/$uid/activity');

  static Stream<List<ActivityEntry>> streamForCurrentUser({int limit = 20}) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Stream<List<ActivityEntry>>.empty();
    return streamForUser(uid: uid, limit: limit);
  }

  static Stream<List<ActivityEntry>> streamForUser({
    required String uid,
    int limit = 20,
  }) {
    final query =
    _userRoot(uid).orderByChild('createdAt').limitToLast(limit);

    return query.onValue.map((event) {
      final data = event.snapshot.value;
      if (data is! Map) return <ActivityEntry>[];

      final entries = <ActivityEntry>[];
      data.forEach((k, v) {
        if (k is! String || v is! Map) return;
        entries.add(ActivityEntry.fromMap(k, Map<String, dynamic>.from(v)));
      });

      entries.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return entries;
    });
  }

  static Future<void> add({
    required String action,
    String actor = 'app',
    String? deviceId,
    String? uid,
  }) async {
    final resolvedUid = uid ?? FirebaseAuth.instance.currentUser?.uid;
    if (resolvedUid == null) return;

    final ref = _userRoot(resolvedUid).push();
    await ref.set({
      'action': action,
      'actor': actor,
      'deviceId': deviceId,
      'createdAt': ServerValue.timestamp,
    });
  }
}
