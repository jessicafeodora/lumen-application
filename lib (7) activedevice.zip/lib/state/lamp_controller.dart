import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:lumen_application/services/rtdb_service.dart';
import 'package:lumen_application/services/activity_rtdb.dart';

/// =========================
/// Central logging helper
/// =========================
void lumenLog(String msg, {Object? err, StackTrace? st}) {
  if (!kDebugMode) return;
  final t = DateTime.now().toIso8601String();
  debugPrint('[$t][Lumen] $msg');
  if (err != null) debugPrint('  err=$err');
  if (st != null) debugPrint('  st=$st');
}

/// =========================
/// UI/App state (theme, auth, signout UX)
/// =========================
class AppState extends ChangeNotifier {
  static const String _kThemeModeKey = 'themeMode';

  ThemeMode themeMode = ThemeMode.light;

  bool isSigningOut = false;
  User? user;

  StreamSubscription<User?>? _authSub;

  AppState() {
    _loadThemeMode();
    _authSub = FirebaseAuth.instance.authStateChanges().listen((u) {
      user = u;
      notifyListeners();
    });
    user = FirebaseAuth.instance.currentUser;
  }

  Future<void> _loadThemeMode() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final v = sp.getString(_kThemeModeKey);
      if (v == null) return;

      switch (v) {
        case 'system':
          themeMode = ThemeMode.system;
          break;
        case 'dark':
          themeMode = ThemeMode.dark;
          break;
        case 'light':
        default:
          themeMode = ThemeMode.light;
          break;
      }
      notifyListeners();
    } catch (e, st) {
      lumenLog('load theme failed', err: e, st: st);
    }
  }

  Future<void> _saveThemeMode() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final v = themeMode == ThemeMode.dark
          ? 'dark'
          : themeMode == ThemeMode.system
          ? 'system'
          : 'light';
      await sp.setString(_kThemeModeKey, v);
    } catch (e, st) {
      lumenLog('save theme failed', err: e, st: st);
    }
  }

  void toggleTheme() {
    themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
    _saveThemeMode();
    _hapticSelection();
  }

  void setThemeMode(ThemeMode v) {
    themeMode = v;
    notifyListeners();
    _saveThemeMode();
    _hapticSelection();
  }

  Future<void> signOutGracefully() async {
    if (isSigningOut) return;
    isSigningOut = true;
    notifyListeners();
    _hapticMedium();

    try {
      await FirebaseAuth.instance.signOut();
    } catch (e, st) {
      lumenLog('signOut failed', err: e, st: st);
    } finally {
      isSigningOut = false;
      notifyListeners();
    }
  }

  void _hapticSelection() {
    try {
      HapticFeedback.selectionClick();
    } catch (_) {}
  }

  void _hapticMedium() {
    try {
      HapticFeedback.mediumImpact();
    } catch (_) {}
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }
}

/// =========================
/// Device state (RTDB, offline detection, writes, smoothing)
/// =========================
class DeviceState extends ChangeNotifier {
  static const String _kActiveDeviceKeyPrefix = 'activeDeviceId_';
  static const String _kDeviceNameKeyPrefix = 'deviceName_';
  static const String _kAutoOffKeyPrefix = 'autoOff_';

  // UI/device state
  bool isOn = false;
  bool autoOff = false;
  int brightness = 75;
  String mode = 'normal';
  int? timerMinutes;

  String deviceName = 'Living Room Lamp';

  // Connection monitoring
  bool isConnected = false; // Firebase .info/connected
  String? fwVersion;
  DateTime? lastSeen;
  DateTime? _lastRemoteEventAt;

  // Soft warning: write failure
  bool lastWriteFailed = false;
  DateTime? lastWriteFailedAt;

  // Offline / stale detection ticker
  Timer? _staleTicker;

  // User binding
  String? userUid;

  // Device selection (active)
  String? deviceId;
  List<String> allowedDeviceIds = const <String>[];

  // Refs/subscriptions
  DatabaseReference? _rootRef;
  DatabaseReference? _metaRef;
  DatabaseReference? _desiredRef;
  DatabaseReference? _reportedRef;

  late final DatabaseReference _connectedRef;
  StreamSubscription<DatabaseEvent>? _connSub;
  StreamSubscription<DatabaseEvent>? _metaSub;
  StreamSubscription<DatabaseEvent>? _desiredSub;
  StreamSubscription<DatabaseEvent>? _reportedSub;

  bool _applyingRemote = false;

  // Debounce smoothing
  Timer? _brightnessDebounce;

  // Auth listener
  StreamSubscription<User?>? _authSub;

  DeviceState() {
    _connectedRef = RTDBService.globalRef('.info/connected');

    // Start stale ticker: force UI update even when RTDB stops updating
    _staleTicker = Timer.periodic(const Duration(seconds: 30), (_) {
      notifyListeners();
    });

    _listenConnection();

    _authSub = FirebaseAuth.instance.authStateChanges().listen(_onAuthChanged);
    _onAuthChanged(FirebaseAuth.instance.currentUser);
  }

  /// Force re-resolve/reattach device binding for the currently signed-in user.
  /// Useful after pairing or switching activeDeviceId.
  Future<void> refreshForCurrentUser() async {
    await _onAuthChanged(FirebaseAuth.instance.currentUser);
  }

  Future<void> setActiveDevice(String newDeviceId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final id = newDeviceId.trim();
    if (id.isEmpty) return;

    if (!allowedDeviceIds.contains(id)) {
      _hapticError();
      return;
    }

    if (deviceId == id) return;

    deviceId = id;
    notifyListeners();

    await RTDBService.globalRef('users/$uid/activeDeviceId').set(id);
    await _saveActiveDeviceLocal(uid, id);

    await ActivityRTDB.add(
      uid: uid,
      deviceId: id,
      action: 'Switched active device',
      actor: 'app',
    );

    // Reattach listeners to the new device.
    await refreshForCurrentUser();
  }

  // ===== Derived labels =====
  String get lastUpdatedLabel {
    final t = _lastRemoteEventAt;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  String get lastSeenLabel {
    final t = lastSeen;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  /// Offline / stale detection (2 minutes)
  bool get deviceOnline {
    final t = lastSeen;
    if (t == null) return false;
    return DateTime.now().difference(t).inMinutes <= 2;
  }

  /// Disable controls when offline / disconnected / no device selected
  bool get canControl {
    if (deviceId == null || deviceId!.isEmpty) return false;
    if (!isConnected) return false;
    if (!deviceOnline) return false;
    return true;
  }

  // ===== Auth attach/detach =====
  Future<void> _onAuthChanged(User? user) async {
    if (user == null) {
      userUid = null;
      allowedDeviceIds = const <String>[];
      deviceId = null;

      _detachDevice();

      isConnected = false;
      fwVersion = null;
      lastSeen = null;
      _lastRemoteEventAt = null;
      lastWriteFailed = false;
      lastWriteFailedAt = null;

      notifyListeners();
      return;
    }

    userUid = user.uid;

    // Load user-scoped local cache (safe for quick UI boot).
    await _loadLocalUserPrefs(user.uid);

    // Pull allowed devices + active device from RTDB profile.
    await _resolveActiveDeviceFromProfile(user.uid);
    await _loadUserProfile(user.uid);

    if (deviceId == null || deviceId!.isEmpty) {
      _detachDevice();
      notifyListeners();
      return;
    }

    _attachDevice(deviceId!);
  }


  Future<void> _resolveActiveDeviceFromProfile(String uid) async {
    try {
      final userRef = RTDBService.globalRef('users/$uid');

      // Allowed devices
      final devicesSnap = await userRef.child('devices').get();
      final allowed = <String>[];
      final devicesVal = devicesSnap.value;
      if (devicesVal is Map) {
        devicesVal.forEach((k, v) {
          if (k is String && v == true) allowed.add(k);
        });
      }
      allowed.sort();
      allowedDeviceIds = allowed;

      // Active device
      final activeSnap = await userRef.child('activeDeviceId').get();
      final activeRaw = activeSnap.value;
      final active = (activeRaw is String) ? activeRaw.trim() : null;

      if (active != null && active.isNotEmpty && allowed.contains(active)) {
        deviceId = active;
        await _saveActiveDeviceLocal(uid, deviceId!);
        lumenLog('activeDeviceId resolved from profile: $deviceId');
        return;
      }

      if (allowed.isNotEmpty) {
        deviceId = allowed.first;
        await _saveActiveDeviceLocal(uid, deviceId!);

        // Keep profile consistent
        await userRef.child('activeDeviceId').set(deviceId);

        lumenLog('activeDeviceId defaulted to first allowed: $deviceId');
        return;
      }
    } catch (e, st) {
      lumenLog('resolve active device from profile failed', err: e, st: st);
    }

    // Fallback: cached activeDeviceId for this uid
    if (deviceId != null && deviceId!.trim().isNotEmpty) {
      deviceId = deviceId!.trim();
      lumenLog('activeDeviceId fallback from cache: $deviceId');
      return;
    }

    deviceId = null;
  }

  Future<void> _loadUserProfile(String uid) async {
    try {
      final userRef = RTDBService.globalRef('users/$uid');

      final nameSnap = await userRef.child('deviceName').get();
      final nameVal = nameSnap.value;
      if (nameVal is String && nameVal.trim().isNotEmpty) {
        deviceName = nameVal.trim();
        await _saveUserDeviceNameLocal(uid, deviceName);
      } else if (deviceName.trim().isEmpty) {
        deviceName = 'Living Room Lamp';
      }

      final autoSnap = await userRef.child('autoOff').get();
      final autoVal = autoSnap.value;
      if (autoVal is bool) {
        autoOff = autoVal;
        await _saveAutoOffLocal(uid, autoVal);
      }

      notifyListeners();
    } catch (e, st) {
      lumenLog('load user profile failed', err: e, st: st);
    }
  }


  void _attachDevice(String id) {
    final root = RTDBService.deviceRoot(id);
    if (root == null) {
      _detachDevice();
      return;
    }

    _rootRef = root;
    _metaRef = root.child('meta');
    _desiredRef = root.child('desired');
    _reportedRef = root.child('reported');

    _listenMeta();
    _listenDesired();
    _listenReported();

    _claimDeviceIfNeeded();
  }

  void _detachDevice() {
    _metaSub?.cancel();
    _desiredSub?.cancel();
    _reportedSub?.cancel();
    _metaSub = null;
    _desiredSub = null;
    _reportedSub = null;

    _rootRef = null;
    _metaRef = null;
    _desiredRef = null;
    _reportedRef = null;
  }

  // ===== Connection listener =====
  void _listenConnection() {
    _connSub?.cancel();
    _connSub = _connectedRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is bool) {
        isConnected = v;
        notifyListeners();
      }
    });
  }

  void _listenMeta() {
    _metaSub?.cancel();
    final ref = _metaRef;
    if (ref == null) return;

    // Keep subscription in case we later expose more meta fields.
    _metaSub = ref.onValue.listen((_) {
      notifyListeners();
    });
  }

  void _listenDesired() {
    _desiredSub?.cancel();
    final ref = _desiredRef;
    if (ref == null) return;

    _desiredSub = ref.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      _applyingRemote = true;
      try {
        final p = v['isOn'];
        final b = v['brightness'];
        final m = v['mode'];
        final t = v['timerMinutes'];
        final ao = v['autoOff'];

        if (p is bool) isOn = p;
        if (b is num) brightness = b.toInt().clamp(0, 100);
        if (m is String && m.trim().isNotEmpty) mode = m.trim();

        if (t == null) {
          timerMinutes = null;
        } else if (t is num) {
          timerMinutes = t.toInt();
        }

        if (ao is bool) {
          autoOff = ao;
          final uid = userUid;
          if (uid != null) {
            _saveAutoOffLocal(uid, autoOff);
          }
        }

        _lastRemoteEventAt = DateTime.now();
        notifyListeners();
      } finally {
        _applyingRemote = false;
      }
    });
  }

  void _listenReported() {
    _reportedSub?.cancel();
    final ref = _reportedRef;
    if (ref == null) return;

    _reportedSub = ref.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      final fw = v['fwVersion'];
      if (fw is String && fw.trim().isNotEmpty) fwVersion = fw.trim();

      final seen = v['lastSeen'];
      if (seen is int && seen > 0) {
        lastSeen = DateTime.fromMillisecondsSinceEpoch(seen);
      }

      notifyListeners();
    });
  }

  // ===== Local cache =====
  Future<void> _loadLocalUserPrefs(String uid) async {
    try {
      final sp = await SharedPreferences.getInstance();

      final id = sp.getString('$_kActiveDeviceKeyPrefix$uid');
      if (id != null && id.trim().isNotEmpty) deviceId = id.trim();

      final cachedName = sp.getString('$_kDeviceNameKeyPrefix$uid');
      if (cachedName != null && cachedName.trim().isNotEmpty) {
        deviceName = cachedName.trim();
      }

      final cachedAutoOff = sp.getBool('$_kAutoOffKeyPrefix$uid');
      if (cachedAutoOff != null) autoOff = cachedAutoOff;

      notifyListeners();
    } catch (e, st) {
      lumenLog('load local user prefs failed', err: e, st: st);
    }
  }

  Future<void> _saveActiveDeviceLocal(String uid, String id) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('$_kActiveDeviceKeyPrefix$uid', id);
    } catch (e, st) {
      lumenLog('save activeDeviceId local failed', err: e, st: st);
    }
  }

  Future<void> _saveUserDeviceNameLocal(String uid, String name) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('$_kDeviceNameKeyPrefix$uid', name);
    } catch (e, st) {
      lumenLog('save deviceName local failed', err: e, st: st);
    }
  }

  Future<void> _saveAutoOffLocal(String uid, bool v) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setBool('$_kAutoOffKeyPrefix$uid', v);
    } catch (e, st) {
      lumenLog('save autoOff local failed', err: e, st: st);
    }
  }

  // ===== Writes (with failure feedback) =====
  Future<void> _writeDesired(Map<String, dynamic> patch) async {
    if (_applyingRemote) return;
    final ref = _desiredRef;
    if (ref == null) return;

    try {
      lastWriteFailed = false;
      await ref.update(patch);
      await ref.child('updatedAt').set(ServerValue.timestamp);
    } catch (e, st) {
      lastWriteFailed = true;
      lastWriteFailedAt = DateTime.now();
      lumenLog('writeDesired failed patch=$patch', err: e, st: st);
      notifyListeners();
    }
  }

  Future<void> _writeMeta(Map<String, dynamic> patch) async {
    final ref = _metaRef;
    if (ref == null) return;

    try {
      lastWriteFailed = false;
      await ref.update(patch);
    } catch (e, st) {
      lastWriteFailed = true;
      lastWriteFailedAt = DateTime.now();
      lumenLog('writeMeta failed patch=$patch', err: e, st: st);
      notifyListeners();
    }
  }

  // ===== User actions (with haptics + smoothing) =====
  Future<void> setPower(bool v) async {
    if (!canControl) {
      _hapticError();
      return;
    }

    _hapticLight();

    // optimistic UI
    isOn = v;
    if (!isOn) brightness = 0;
    if (isOn && brightness == 0) brightness = 75;
    notifyListeners();

    await _writeDesired({'isOn': isOn, 'brightness': brightness});

    await ActivityRTDB.add(
      uid: FirebaseAuth.instance.currentUser?.uid,
      deviceId: deviceId ?? '',
      action: isOn ? 'Power ON' : 'Power OFF',
      actor: 'app',
    );
  }

  Future<void> setAutoOff(bool v) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    _hapticSelection();

    autoOff = v;
    notifyListeners();

    await _saveAutoOffLocal(uid, v);
    await RTDBService.globalRef('users/$uid/autoOff').set(v);

    if (canControl) {
      await _writeDesired({'autoOff': v});
    }

    await ActivityRTDB.add(
      uid: uid,
      deviceId: deviceId,
      action: v ? 'Auto Off enabled' : 'Auto Off disabled',
      actor: 'app',
    );
  }


  Future<void> setBrightness(int v) async {
    if (!canControl) {
      _hapticError();
      return;
    }

    // optimistic UI
    brightness = v.clamp(0, 100);
    if (brightness > 0) isOn = true;
    notifyListeners();

    // smoothing: debounce network write
    _brightnessDebounce?.cancel();
    _brightnessDebounce = Timer(const Duration(milliseconds: 120), () async {
      await _writeDesired({'brightness': brightness, 'isOn': isOn});

      await ActivityRTDB.add(
        deviceId: deviceId ?? '',
        action: 'Brightness set to $brightness%',
        actor: 'app',
      );
    });
  }

  Future<void> setMode(String v) async {
    if (!canControl) {
      _hapticError();
      return;
    }

    _hapticSelection();

    mode = v;
    notifyListeners();

    await _writeDesired({'mode': mode});

    await ActivityRTDB.add(
      uid: FirebaseAuth.instance.currentUser?.uid,
      deviceId: deviceId ?? '',
      action: 'Mode changed to $mode',
      actor: 'app',
    );
  }

  Future<void> setTimer(int? minutes) async {
    if (!canControl) {
      _hapticError();
      return;
    }

    _hapticSelection();

    timerMinutes = minutes;
    notifyListeners();

    await _writeDesired({'timerMinutes': timerMinutes});

    await ActivityRTDB.add(
      uid: FirebaseAuth.instance.currentUser?.uid,
      deviceId: deviceId ?? '',
      action: timerMinutes == null ? 'Timer cleared' : 'Timer set to ${timerMinutes}m',
      actor: 'app',
    );
  }

  Future<void> setDeviceName(String name) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (trimmed == deviceName) return;

    _hapticSelection();

    deviceName = trimmed;
    notifyListeners();

    await _saveUserDeviceNameLocal(uid, trimmed);

    // User-specific label (does not modify device-global meta)
    await RTDBService.globalRef('users/$uid/deviceName').set(trimmed);

    await ActivityRTDB.add(
      uid: uid,
      deviceId: deviceId,
      action: 'Device name set to "$trimmed"',
      actor: 'app',
    );
  }


  // ===== Claim device =====
  bool _claiming = false;

  Future<void> _claimDeviceIfNeeded() async {
    if (_claiming) return;
    _claiming = true;

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final meta = _metaRef;
      if (meta == null) return;

      final ownerRef = meta.child('ownerUid');
      final snap = await ownerRef.get();
      final owner = snap.value;

      if (owner == null || (owner is String && owner.trim().isEmpty)) {
        await ownerRef.set(user.uid);
      }
    } catch (e, st) {
      lumenLog('claimDevice failed', err: e, st: st);
    } finally {
      _claiming = false;
    }
  }

  // ===== Haptics =====
  void _hapticSelection() {
    try {
      HapticFeedback.selectionClick();
    } catch (_) {}
  }

  void _hapticLight() {
    try {
      HapticFeedback.lightImpact();
    } catch (_) {}
  }

  void _hapticError() {
    try {
      HapticFeedback.mediumImpact();
    } catch (_) {}
  }

  @override
  void dispose() {
    _brightnessDebounce?.cancel();
    _staleTicker?.cancel();

    _authSub?.cancel();
    _connSub?.cancel();
    _detachDevice();

    super.dispose();
  }
}

/// =========================
/// Facade (keeps old API stable)
/// =========================
class LampController extends ChangeNotifier {
  final AppState app = AppState();
  final DeviceState device = DeviceState();

  LampController() {
    app.addListener(notifyListeners);
    device.addListener(notifyListeners);
  }

  // ---- Old fields/properties (forwarders) ----
  ThemeMode get themeMode => app.themeMode;
  void toggleTheme() => app.toggleTheme();
  void setThemeMode(ThemeMode v) => app.setThemeMode(v);

  bool get isSigningOut => app.isSigningOut;
  User? get user => app.user;

  bool get isOn => device.isOn;
  bool get autoOff => device.autoOff;
  int get brightness => device.brightness;
  String get mode => device.mode;
  int? get timerMinutes => device.timerMinutes;

  String get deviceName => device.deviceName;
  String? get deviceId => device.deviceId;
  String? get userUid => device.userUid;
  List<String> get allowedDeviceIds => device.allowedDeviceIds;


  Future<void> refreshForCurrentUser() => device.refreshForCurrentUser();
  Future<void> setActiveDevice(String id) => device.setActiveDevice(id);

  bool get isConnected => device.isConnected;
  bool get deviceOnline => device.deviceOnline;
  bool get canControl => device.canControl && !app.isSigningOut;

  String? get fwVersion => device.fwVersion;
  DateTime? get lastSeen => device.lastSeen;
  String get lastSeenLabel => device.lastSeenLabel;
  String get lastUpdatedLabel => device.lastUpdatedLabel;

  bool get lastWriteFailed => device.lastWriteFailed;
  DateTime? get lastWriteFailedAt => device.lastWriteFailedAt;

  // ---- Actions ----
  Future<void> setPower(bool v) => app.isSigningOut ? Future.value() : device.setPower(v);
  Future<void> setAutoOff(bool v) => app.isSigningOut ? Future.value() : device.setAutoOff(v);
  Future<void> setBrightness(int v) => app.isSigningOut ? Future.value() : device.setBrightness(v);
  Future<void> setMode(String v) => app.isSigningOut ? Future.value() : device.setMode(v);
  Future<void> setTimer(int? minutes) => app.isSigningOut ? Future.value() : device.setTimer(minutes);
  Future<void> setDeviceName(String name) => app.isSigningOut ? Future.value() : device.setDeviceName(name);

  Future<void> signOutGracefully() => app.signOutGracefully();

  @override
  void dispose() {
    app.removeListener(notifyListeners);
    device.removeListener(notifyListeners);
    app.dispose();
    device.dispose();
    super.dispose();
  }
}