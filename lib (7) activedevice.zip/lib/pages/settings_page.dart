import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/header.dart';

class SettingsPage extends StatefulWidget {
  final LampController controller;
  const SettingsPage({super.key, required this.controller});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _nameCtrl;

  static const double _contentInset = 22.0;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.controller.deviceName);
    widget.controller.addListener(_syncName);
  }

  void _syncName() {
    final current = widget.controller.deviceName;
    if (_nameCtrl.text != current) {
      _nameCtrl.value = _nameCtrl.value.copyWith(
        text: current,
        selection: TextSelection.collapsed(offset: current.length),
        composing: TextRange.empty,
      );
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_syncName);
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;

    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          body: LayoutBuilder(
            builder: (_, c) {
              final isDesktop = c.maxWidth >= 1024;
              final maxWidth = isDesktop ? 980.0 : double.infinity;

              final topSafe = MediaQuery.of(context).padding.top;
              const headerSide = 12.0;
              const headerTopGap = 8.0;
              const headerBottomGap = 40.0;

              final headerTop = topSafe + headerTopGap;
              final headerHeight = LumenHeader.cardHeight;
              final contentTopMin = headerTop + headerHeight + headerBottomGap;

              final horizontalPadding = c.maxWidth < 640 ? 16.0 : 24.0;
              final contentTop = math.max(24.0, contentTopMin);

              return Stack(
                children: [
                  Positioned.fill(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.fromLTRB(
                        horizontalPadding,
                        contentTop,
                        horizontalPadding,
                        32,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: maxWidth),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: _contentInset),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Settings',
                                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Text(
                                      'Customize your Lúmen experience',
                                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onSurface
                                            .withOpacity(0.62),
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 44),

                              _sectionLabel(context, 'GENERAL'),
                              const SizedBox(height: 16),

                              // Theme
                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: _contentInset,
                                  vertical: 18,
                                ),
                                child: _settingRow(
                                  context,
                                  icon: Icons.wb_sunny_outlined,
                                  title: 'Theme',
                                  subtitle: 'Choose your preferred appearance',
                                  trailing: DropdownButtonHideUnderline(
                                    child: DropdownButton<ThemeMode>(
                                      value: controller.themeMode,
                                      onChanged: (v) {
                                        if (v != null) controller.setThemeMode(v);
                                      },
                                      items: const [
                                        DropdownMenuItem(
                                          value: ThemeMode.system,
                                          child: Text('System'),
                                        ),
                                        DropdownMenuItem(
                                          value: ThemeMode.light,
                                          child: Text('Light'),
                                        ),
                                        DropdownMenuItem(
                                          value: ThemeMode.dark,
                                          child: Text('Dark'),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 16),

                              // Active Device (multidevice-ready)
                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: _contentInset,
                                  vertical: 18,
                                ),
                                child: _settingRow(
                                  context,
                                  icon: Icons.devices,
                                  title: 'Active Device',
                                  subtitle: 'Choose which lamp you control',
                                  trailing: _DeviceSelector(controller: controller),
                                ),
                              ),

                              const SizedBox(height: 16),

                              // Device Name (user-specific) — responsive to avoid overflow on mobile
                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: _contentInset,
                                  vertical: 18,
                                ),
                                child: LayoutBuilder(
                                  builder: (context, rowC) {
                                    final isNarrow = rowC.maxWidth < 420;

                                    final label = _settingLabel(
                                      context,
                                      icon: Icons.bolt,
                                      title: 'Device Name',
                                      subtitle: 'Customize your lamp name',
                                    );

                                    final field = ConstrainedBox(
                                      constraints: const BoxConstraints(maxWidth: 260),
                                      child: TextField(
                                        controller: _nameCtrl,
                                        textInputAction: TextInputAction.done,
                                        onChanged: controller.setDeviceName,
                                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                          fontWeight: FontWeight.w700,
                                        ),
                                        decoration: const InputDecoration(
                                          isDense: true,
                                          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                          border: OutlineInputBorder(borderSide: BorderSide.none),
                                          filled: true,
                                        ),
                                      ),
                                    );

                                    if (isNarrow) {
                                      return Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          label,
                                          const SizedBox(height: 12),
                                          field,
                                        ],
                                      );
                                    }

                                    return Row(
                                      children: [
                                        Expanded(child: label),
                                        const SizedBox(width: 16),
                                        Flexible(child: field),
                                      ],
                                    );
                                  },
                                ),
                              ),

                              const SizedBox(height: 44),

                              _sectionLabel(context, 'ACCOUNT'),
                              const SizedBox(height: 16),

                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: _contentInset,
                                  vertical: 18,
                                ),
                                child: Column(
                                  children: [
                                    _kv(context, 'Email', controller.user?.email ?? '—'),
                                    const SizedBox(height: 10),
                                    _kv(context, 'User ID', controller.user?.uid ?? '—'),
                                    const SizedBox(height: 16),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: TextButton.icon(
                                        onPressed: () async {
                                          await controller.signOutGracefully();
                                          if (context.mounted) {
                                            Navigator.of(context).pushNamedAndRemoveUntil('/auth', (_) => false);
                                          }
                                        },
                                        icon: const Icon(Icons.logout, size: 18),
                                        label: const Text('Sign out'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 44),

                              _sectionLabel(context, 'ABOUT'),
                              const SizedBox(height: 16),

                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: _contentInset,
                                  vertical: 18,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Lúmen',
                                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      'Glassmorphism UI prototype for lamp control.',
                                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onSurface
                                            .withOpacity(0.70),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  Positioned(
                    top: headerTop,
                    left: headerSide,
                    right: headerSide,
                    child: LumenHeader(
                      controller: controller,
                      showSettings: false,
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _sectionLabel(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.only(left: _contentInset),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
          fontWeight: FontWeight.w900,
          letterSpacing: 1.2,
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55),
        ),
      ),
    );
  }

  Widget _settingLabel(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String subtitle,
      }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withOpacity(0.62),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _settingRow(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String subtitle,
        required Widget trailing,
      }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withOpacity(0.62),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 16),
        Flexible(child: trailing),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v) {
    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context)
                  .colorScheme
                  .onSurface
                  .withOpacity(0.60),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Text(
          v,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _DeviceSelector extends StatelessWidget {
  final LampController controller;
  const _DeviceSelector({required this.controller});

  @override
  Widget build(BuildContext context) {
    final allowed = controller.allowedDeviceIds;
    final current = controller.deviceId;

    if (allowed.isEmpty) {
      return Text(
        '—',
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      );
    }

    final value = (current != null && allowed.contains(current)) ? current : allowed.first;

    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 240),
      child: DropdownButtonFormField<String>(
        value: value,
        isExpanded: true,
        decoration: const InputDecoration(
          isDense: true,
          border: OutlineInputBorder(borderSide: BorderSide.none),
          filled: true,
        ),
        items: allowed
            .map(
              (id) => DropdownMenuItem<String>(
            value: id,
            child: Text(
              id,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        )
            .toList(),
        onChanged: (v) {
          final next = v ?? value;
          controller.setActiveDevice(next);
        },
      ),
    );
  }
}
