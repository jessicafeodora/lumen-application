import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:lumen_application/services/activity_rtdb.dart';
import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/widgets/activity_log.dart';
import 'package:lumen_application/widgets/brightness_slider.dart';
import 'package:lumen_application/widgets/connection_status.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/header.dart';
import 'package:lumen_application/widgets/mode_selector.dart';
import 'package:lumen_application/widgets/power_toggle.dart';
import 'package:lumen_application/widgets/timer_chips.dart';

class HomePage extends StatelessWidget {
  final LampController controller;
  const HomePage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        if (controller.allowedDeviceIds.isEmpty) {
          return _NoDeviceAssigned(controller: controller);
        }

        return Scaffold(
          extendBodyBehindAppBar: true,
          body: LayoutBuilder(
            builder: (context, constraints) {
              final screenW = constraints.maxWidth;
              final isDesktop = screenW >= 1024;

              final topSafe = MediaQuery.of(context).padding.top;
              const headerSide = 12.0;
              const headerTopGap = 8.0;
              const headerBottomGap = 55.0;

              final headerTop = topSafe + headerTopGap;
              final headerHeight = LumenHeader.cardHeight;
              final contentTopMin = headerTop + headerHeight + headerBottomGap;

              final horizontalPadding = screenW < 640 ? 16.0 : 24.0;
              final bottomPadding = isDesktop ? 24.0 : 110.0;

              final contentTop = math.max(isDesktop ? 24.0 : 20.0, contentTopMin);

              return Stack(
                children: [
                  Positioned.fill(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.fromLTRB(
                        horizontalPadding,
                        contentTop,
                        horizontalPadding,
                        bottomPadding,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1280),
                          child: isDesktop
                              ? Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 8,
                                child: _LeftColumn(
                                  controller: controller,
                                  isDesktop: true,
                                ),
                              ),
                              const SizedBox(width: 24),
                              Expanded(
                                flex: 4,
                                child: _RightColumn(controller: controller),
                              ),
                            ],
                          )
                              : _LeftColumn(
                            controller: controller,
                            isDesktop: false,
                          ),
                        ),
                      ),
                    ),
                  ),

                  Positioned(
                    top: headerTop,
                    left: headerSide,
                    right: headerSide,
                    child: LumenHeader(
                      controller: controller,
                      showSettings: true,
                    ),
                  ),

                  if (!isDesktop)
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                        child: Glass(
                          size: GlassSize.md,
                          padding: const EdgeInsets.all(12),
                          borderRadius: BorderRadius.circular(22),
                          child: SafeArea(
                            top: false,
                            child: ConnectionStatusBar(
                              isConnected: controller.isConnected,
                              showOnlineRight: true,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _LeftColumn extends StatelessWidget {
  final LampController controller;
  final bool isDesktop;

  const _LeftColumn({
    required this.controller,
    required this.isDesktop,
  });

  @override
  Widget build(BuildContext context) {
    final pad = isDesktop ? 40.0 : 28.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Glass(
          size: GlassSize.lg,
          glow: controller.isOn,
          borderRadius: BorderRadius.circular(28),
          padding: EdgeInsets.all(pad),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                controller.deviceName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                controller.isOn ? 'ON • ${controller.brightness}%' : 'OFF',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.45),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 22),
              PowerToggle(
                isOn: controller.isOn,
                label: controller.deviceName,
                onToggle: controller.setPower,
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        LayoutBuilder(
          builder: (_, c) {
            final w = c.maxWidth;
            final twoCol = w >= 640;

            return Wrap(
              spacing: 20,
              runSpacing: 20,
              children: [
                SizedBox(
                  width: twoCol ? (w - 20) / 2 : w,
                  child: BrightnessCard(
                    value: controller.isOn ? controller.brightness : 0,
                    disabled: !controller.isOn,
                    onChanged: controller.setBrightness,
                  ),
                ),
                SizedBox(
                  width: twoCol ? (w - 20) / 2 : w,
                  child: TimerCard(
                    selectedMinutes: controller.timerMinutes,
                    onSelect: controller.setTimer,
                  ),
                ),
              ],
            );
          },
        ),

        const SizedBox(height: 20),

        ModeSelectorCard(
          selected: controller.mode,
          onSelect: controller.setMode,
        ),

        const SizedBox(height: 20),

        if (!isDesktop) _ActivityStream(uid: controller.userUid),
      ],
    );
  }
}

class _RightColumn extends StatelessWidget {
  final LampController controller;
  const _RightColumn({required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.all(24),
          borderRadius: BorderRadius.circular(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Device Status',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 16),
              ConnectionStatusTile(
                isConnected: controller.isConnected,
                deviceName: controller.deviceId ?? '—',
                lastUpdated: controller.lastUpdatedLabel,
              ),

              const SizedBox(height: 16),
              Divider(color: Colors.white.withOpacity(isDark ? 0.10 : 0.20)),
              const SizedBox(height: 16),

              _kv(context, 'Firmware', controller.fwVersion ?? '—'),
              const SizedBox(height: 12),
              _kv(context, 'Last seen', controller.lastSeenLabel),
              const SizedBox(height: 12),
              _kv(context, 'Device', controller.deviceOnline ? 'Online' : 'Offline'),
            ],
          ),
        ),

        const SizedBox(height: 20),

        _ActivityStream(uid: controller.userUid),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v) {
    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.50),
            ),
          ),
        ),
        Text(
          v,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _ActivityStream extends StatelessWidget {
  final String? uid;
  const _ActivityStream({required this.uid});

  @override
  Widget build(BuildContext context) {
    final userId = uid;
    if (userId == null) {
      return const ActivityLogCard(entries: <ActivityEntry>[]);
    }

    return StreamBuilder<List<ActivityEntry>>(
      stream: ActivityRTDB.streamForUser(uid: userId, limit: 20),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const ActivityLogCard(entries: <ActivityEntry>[]);
        }
        return ActivityLogCard(entries: snap.data ?? const <ActivityEntry>[]);
      },
    );
  }
}

class _NoDeviceAssigned extends StatelessWidget {
  final LampController controller;

  const _NoDeviceAssigned({required this.controller});

  @override
  Widget build(BuildContext context) {
    final topSafe = MediaQuery.of(context).padding.top;

    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          Positioned.fill(
            child: ColoredBox(
              color: Theme.of(context).scaffoldBackgroundColor,
            ),
          ),

          Positioned(
            left: 12,
            right: 12,
            top: topSafe + 8,
            child: LumenHeader(
              controller: controller,
              showSettings: true,
            ),
          ),

          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Glass(
                  size: GlassSize.lg,
                  borderRadius: BorderRadius.circular(26),
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'No device assigned',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'This account does not have any allowed devices yet. Open Settings to check Active Device, or ask admin to assign one.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onBackground.withOpacity(0.70),
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
