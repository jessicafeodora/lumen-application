import 'package:flutter/material.dart';

class LumenLogo extends StatelessWidget {
  final double size;
  const LumenLogo({super.key, this.size = 64});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFFD36E),
            Color(0xFF4A70A9),
            Color(0xFF8FABD4),
          ],
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 18,
            offset: const Offset(0, 10),
            color: Colors.black.withValues(alpha: isDark ? 0.30 : 0.10),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: const Text(
        'L',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w900,
          color: Colors.white,
        ),
      ),
    );
  }
}
