import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:lumen_application/services/rtdb_service.dart';
import 'package:lumen_application/services/activity_rtdb.dart';

class LampController extends ChangeNotifier {
  // -------------------------
  // UI state
  // -------------------------
  bool isOn = false;
  int brightness = 75;
  String mode = 'normal';
  int? timerMinutes;

  bool isConnected = false;

  final String deviceId = 'ESP32-Lamp';

  String deviceName = 'Living Room';

  ThemeMode themeMode = ThemeMode.light;

  // From reported (monitoring)
  String? fwVersion;
  DateTime? lastSeen;

  // timestamps for UI
  DateTime? _lastRemoteEventAt;
  String get lastUpdatedLabel {
    final t = _lastRemoteEventAt;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  String get lastSeenLabel {
    final t = lastSeen;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  bool get deviceOnline {
    final t = lastSeen;
    if (t == null) return false;
    return DateTime.now().difference(t).inSeconds <= 30;
  }

  // -------------------------
  // RTDB refs
  // -------------------------
  late final DatabaseReference _rootRef;
  late final DatabaseReference _metaRef;
  late final DatabaseReference _desiredRef;
  late final DatabaseReference _reportedRef;
  late final DatabaseReference _connectedRef;

  StreamSubscription<DatabaseEvent>? _metaSub;
  StreamSubscription<DatabaseEvent>? _desiredSub;
  StreamSubscription<DatabaseEvent>? _reportedSub;
  StreamSubscription<DatabaseEvent>? _connSub;

  bool _applyingRemote = false;
  bool _claimed = false;

  LampController() {
    _rootRef = RTDBService.ref('devices/$deviceId');
    _metaRef = _rootRef.child('meta');
    _desiredRef = _rootRef.child('desired');
    _reportedRef = _rootRef.child('reported');
    _connectedRef = RTDBService.ref('.info/connected');

    _listenConnection();
    _listenMeta();
    _listenDesiredFallback();
    _listenReportedPrimary();

    _claimDeviceIfNeeded();
  }

  // -------------------------
  // Connection status
  // -------------------------
  void _listenConnection() {
    _connSub?.cancel();
    _connSub = _connectedRef.onValue.listen((event) {
      final next = event.snapshot.value == true;
      if (next != isConnected) {
        isConnected = next;
        notifyListeners();
      }
    }, onError: (_) {
      if (isConnected != false) {
        isConnected = false;
        notifyListeners();
      }
    });
  }

  // -------------------------
  // Meta: name + owner
  // -------------------------
  void _listenMeta() {
    _metaSub?.cancel();
    _metaSub = _metaRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      final name = v['name'];
      if (name is String && name.trim().isNotEmpty) {
        final trimmed = name.trim();
        if (trimmed != deviceName) {
          deviceName = trimmed;
          notifyListeners();
        }
      }
    });
  }

  Future<void> _claimDeviceIfNeeded() async {
    if (_claimed) return;

    await Future<void>.delayed(const Duration(milliseconds: 50));

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final ownerRef = _metaRef.child('ownerUid');

    try {
      final snap = await ownerRef.get();
      final owner = snap.value;

      // IMPORTANT: only claim if empty/unset (so we don't steal devices)
      if (!snap.exists || owner == null || (owner is String && owner.isEmpty)) {
        await ownerRef.set(user.uid);
      }

      _claimed = true;
    } catch (_) {
      // rules might deny; ignore for now
    }
  }

  // -------------------------
  // State listeners
  // reported = primary, desired = fallback for first-load
  // -------------------------
  void _listenReportedPrimary() {
    _reportedSub?.cancel();
    _reportedSub = _reportedRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;
      _applyRemoteState(v);
    });
  }

  void _listenDesiredFallback() {
    _desiredSub?.cancel();
    _desiredSub = _desiredRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      // Apply desired only before we have any remote report
      if (_lastRemoteEventAt == null) {
        _applyRemoteState(v);
      }
    });
  }

  void _applyRemoteState(Map v) {
    _applyingRemote = true;
    try {
      final remotePower = v['isOn'];
      final remoteBrightness = v['brightness'];
      final remoteMode = v['mode'];
      final remoteTimer = v['timerMinutes'];

      if (remotePower is bool) isOn = remotePower;

      if (remoteBrightness is int) {
        brightness = remoteBrightness.clamp(0, 100);
      } else if (remoteBrightness is num) {
        brightness = remoteBrightness.toInt().clamp(0, 100);
      }

      if (remoteMode is String && remoteMode.isNotEmpty) {
        mode = remoteMode;
      }

      if (remoteTimer == null) {
        timerMinutes = null;
      } else if (remoteTimer is int) {
        timerMinutes = remoteTimer;
      } else if (remoteTimer is num) {
        timerMinutes = remoteTimer.toInt();
      }

      // monitoring fields from reported
      final remoteFw = v['fwVersion'];
      if (remoteFw is String && remoteFw.trim().isNotEmpty) {
        fwVersion = remoteFw.trim();
      }

      final remoteLastSeen = v['lastSeen'];
      if (remoteLastSeen is int) {
        lastSeen = DateTime.fromMillisecondsSinceEpoch(remoteLastSeen);
      } else if (remoteLastSeen is num) {
        lastSeen = DateTime.fromMillisecondsSinceEpoch(remoteLastSeen.toInt());
      }

      _lastRemoteEventAt = DateTime.now();
      notifyListeners();
    } finally {
      _applyingRemote = false;
    }
  }

  // -------------------------
  // Theme (local only)
  // -------------------------
  void toggleTheme() {
    themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    themeMode = mode;
    notifyListeners();
  }

  // -------------------------
  // Write to desired (with server timestamp)
  // -------------------------
  Future<void> _writeDesired(Map<String, dynamic> patch) async {
    if (_applyingRemote) return;

    patch['updatedAt'] = ServerValue.timestamp;

    try {
      await _desiredRef.update(patch);
    } catch (_) {}
  }

  // -------------------------
  // Actions (write + activity)
  // -------------------------
  Future<void> setPower(bool v) async {
    isOn = v;

    if (!isOn) {
      brightness = 0;
    } else {
      if (brightness == 0) brightness = 75;
    }

    notifyListeners();

    await _writeDesired({
      'isOn': isOn,
      'brightness': brightness,
      'mode': mode,
      'timerMinutes': timerMinutes,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: isOn ? 'Power ON' : 'Power OFF',
          );
  }

  Future<void> setBrightness(int v) async {
    brightness = v.clamp(0, 100);
    if (brightness > 0) isOn = true;

    notifyListeners();

    await _writeDesired({
      'brightness': brightness,
      'isOn': isOn,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Brightness set to $brightness%',
    );
  }

  Future<void> setMode(String v) async {
    mode = v;
    notifyListeners();

    await _writeDesired({'mode': mode});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Mode changed to $mode',
    );
  }

  Future<void> setTimer(int? minutes) async {
    timerMinutes = minutes;
    notifyListeners();

    await _writeDesired({'timerMinutes': timerMinutes});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: minutes == null ? 'Timer cleared' : 'Timer set to ${timerMinutes}m',
    );
  }

  Future<void> setDeviceName(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (trimmed == deviceName) return;

    deviceName = trimmed;
    notifyListeners();

    try {
      await _metaRef.child('name').set(deviceName);
    } catch (_) {}

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Device renamed to "$deviceName"',
    );
  }

  @override
  void dispose() {
    _metaSub?.cancel();
    _desiredSub?.cancel();
    _reportedSub?.cancel();
    _connSub?.cancel();
    super.dispose();
  }
}
