import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum GlassSize { sm, md, lg }

class Glass extends StatefulWidget {
  final Widget child;

  final GlassSize size;
  final bool interactive;

  /// When true, draws an OUTER halo behind the card (does NOT tint the surface).
  final bool glow;

  final EdgeInsets? padding;
  final BorderRadius? borderRadius;
  final BoxBorder? borderOverride;
  final Color? tintOverride;

  /// Expected UI: no thin highlight line on top for most cards.
  final bool enableTopHighlight;

  const Glass({
    super.key,
    required this.child,
    this.size = GlassSize.md,
    this.interactive = false,
    this.glow = false,
    this.padding,
    this.borderRadius,
    this.borderOverride,
    this.tintOverride,
    this.enableTopHighlight = false,
  });

  @override
  State<Glass> createState() => _GlassState();
}

class _GlassState extends State<Glass> {
  bool _hover = false;
  bool _pressed = false;

  double get _blur {
    switch (widget.size) {
      case GlassSize.sm:
        return 16;
      case GlassSize.md:
        return 20;
      case GlassSize.lg:
        return 24;
    }
  }

  BorderRadius get _radius {
    if (widget.borderRadius != null) return widget.borderRadius!;
    switch (widget.size) {
      case GlassSize.sm:
        return BorderRadius.circular(16);
      case GlassSize.md:
        return BorderRadius.circular(20);
      case GlassSize.lg:
        return BorderRadius.circular(28);
    }
  }

  double get _tintAlpha {
    // spec: 10–20% white
    switch (widget.size) {
      case GlassSize.sm:
        return 0.12;
      case GlassSize.md:
        return 0.16;
      case GlassSize.lg:
        return 0.20;
    }
  }

  double get _borderAlpha {
    // spec: 20–35% border
    switch (widget.size) {
      case GlassSize.sm:
        return 0.20;
      case GlassSize.md:
        return 0.26;
      case GlassSize.lg:
        return 0.30;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final translateY = (!widget.interactive)
        ? 0.0
        : (_pressed ? 0.0 : (_hover ? -2.0 : 0.0));
    final scale = (!widget.interactive) ? 1.0 : (_pressed ? 0.98 : 1.0);

    final baseTint = widget.tintOverride ??
        Colors.white.withValues(alpha: isDark ? (_tintAlpha * 0.75) : _tintAlpha);

    final borderColor = Colors.white.withValues(
      alpha: (_borderAlpha + (_hover ? 0.06 : 0.0)) * (isDark ? 0.85 : 1.0),
    );

    final border = widget.borderOverride ??
        Border.all(
          color: borderColor,
          width: 1,
        );

    // --- OUTER glow (HALO) behind card — does NOT tint surface ---
    final glowColor = isDark ? const Color(0xFF7DE3FF) : const Color(0xFFFFD36E);

    // Subtle double shadow for depth (expected)
    final shadow1 = BoxShadow(
      blurRadius: 24,
      offset: const Offset(0, 18),
      color: Colors.black.withValues(alpha: isDark ? 0.28 : 0.08),
    );
    final shadow2 = BoxShadow(
      blurRadius: 10,
      offset: const Offset(0, 6),
      color: Colors.black.withValues(alpha: isDark ? 0.22 : 0.05),
    );

    Widget cardSurface = ClipRRect(
      borderRadius: _radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: _blur, sigmaY: _blur),
        child: Container(
          padding: widget.padding,
          decoration: BoxDecoration(
            borderRadius: _radius,
            color: baseTint,
            border: border,
          ),
          child: Stack(
            children: [
              // optional top highlight (OFF by default to remove thin line)
              if (widget.enableTopHighlight)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: IgnorePointer(
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            Colors.white.withValues(alpha: isDark ? 0.18 : 0.28),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              widget.child,
            ],
          ),
        ),
      ),
    );

    // Wrap with halo glow behind + shadows
    Widget composed = Stack(
      clipBehavior: Clip.none,
      children: [
        if (widget.glow)
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: _radius,
                  boxShadow: [
                    // halo layers (outside)
                    BoxShadow(
                      color: glowColor.withValues(alpha: isDark ? 0.22 : 0.18),
                      blurRadius: 48,
                      spreadRadius: 6,
                      offset: const Offset(0, 10),
                    ),
                    BoxShadow(
                      color: glowColor.withValues(alpha: isDark ? 0.12 : 0.10),
                      blurRadius: 90,
                      spreadRadius: 14,
                      offset: const Offset(0, 22),
                    ),
                  ],
                ),
              ),
            ),
          ),

        // real glass surface + depth shadows
        DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: _radius,
            boxShadow: [shadow2, shadow1],
          ),
          child: cardSurface,
        ),
      ],
    );

    if (!widget.interactive) return composed;

    // Interactions
    composed = AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOut,
      transform: Matrix4.identity()..translate(0.0, translateY)..scale(scale),
      child: composed,
    );

    if (!kIsWeb) {
      return GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        child: composed,
      );
    }

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() {
        _hover = false;
        _pressed = false;
      }),
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        child: composed,
      ),
    );
  }
}
