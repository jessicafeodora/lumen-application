import 'package:flutter/material.dart';
import 'package:lumen_application/widgets/glass.dart';

class ModeSelectorCard extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelect;

  const ModeSelectorCard({
    super.key,
    required this.selected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Glass(
      size: GlassSize.md,
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Mode', style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          _tile(context, 'normal', 'Normal', 'Bright & warm'),
          const SizedBox(height: 12),
          _tile(context, 'reading', 'Reading', 'Focused light'),
          const SizedBox(height: 12),
          _tile(context, 'night', 'Night', 'Soft glow'),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, String key, String title, String sub) {
    final isSelected = selected == key;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: () => onSelect(key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: isSelected
              ? Colors.white.withOpacity(isDark ? 0.12 : 0.18)
              : Colors.white.withOpacity(isDark ? 0.05 : 0.10),
          border: Border.all(
            color: Colors.white.withOpacity(isSelected ? (isDark ? 0.22 : 0.30) : (isDark ? 0.12 : 0.18)),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
              sub,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
