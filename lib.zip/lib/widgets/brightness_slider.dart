import 'package:flutter/material.dart';
import 'package:lumen_application/theme/lumen_theme.dart';
import 'package:lumen_application/widgets/glass.dart';

class BrightnessCard extends StatelessWidget {
  final int value;
  final bool disabled;
  final ValueChanged<int> onChanged;

  const BrightnessCard({
    super.key,
    required this.value,
    required this.disabled,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Stack(
      children: [
        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.wb_sunny_outlined,
                    size: 20,
                    color: value > 50
                        ? (isDark ? LumenColors.darkAccent : LumenColors.lightAccent)
                        : Theme.of(context).colorScheme.onSurface.withOpacity(0.45),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Brightness',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              _GradientSlider(
                value: value,
                disabled: disabled,
                onChanged: onChanged,
              ),

              const SizedBox(height: 14),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '$value%',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Glow effect when high brightness (ZIP: value > 70)
        if (value > 70)
          Positioned.fill(
            child: IgnorePointer(
              child: Opacity(
                opacity: 0.30,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: const RadialGradient(
                      colors: [
                        Color.fromRGBO(255, 211, 110, 0.20),
                        Colors.transparent,
                      ],
                      radius: 0.9,
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _GradientSlider extends StatefulWidget {
  final int value;
  final bool disabled;
  final ValueChanged<int> onChanged;

  const _GradientSlider({
    required this.value,
    required this.disabled,
    required this.onChanged,
  });

  @override
  State<_GradientSlider> createState() => _GradientSliderState();
}

class _GradientSliderState extends State<_GradientSlider> {
  bool dragging = false;

  void _setFromDx(double dx, double width) {
    final t = (dx / width).clamp(0.0, 1.0);
    widget.onChanged((t * 100).round());
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final trackBg = Colors.white.withOpacity(isDark ? 0.10 : 0.15);

    return LayoutBuilder(
      builder: (_, c) {
        final w = c.maxWidth;
        final t = widget.value / 100.0;
        final thumbX = (w * t);

        return GestureDetector(
          onPanStart: widget.disabled ? null : (_) => setState(() => dragging = true),
          onPanEnd: widget.disabled ? null : (_) => setState(() => dragging = false),
          onPanUpdate: widget.disabled
              ? null
              : (d) => _setFromDx(d.localPosition.dx, w),
          onTapDown: widget.disabled
              ? null
              : (d) => _setFromDx(d.localPosition.dx, w),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOut,
            transform: Matrix4.identity()..scale(1.0, dragging ? 1.5 : 1.0),
            transformAlignment: Alignment.centerLeft,
            height: 22,
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                // Track with exact gradient logic from ZIP:
                // gold 0- value, then white/15 remainder
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: Container(
                    height: 8,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        stops: [
                          0.0,
                          t.clamp(0.0, 1.0),
                          t.clamp(0.0, 1.0),
                          1.0,
                        ],
                        colors: [
                          const Color.fromRGBO(255, 211, 110, 0.30),
                          const Color.fromRGBO(255, 211, 110, 0.60),
                          trackBg,
                          trackBg,
                        ],
                      ),
                    ),
                  ),
                ),

                // Thumb (glass circle)
                Positioned(
                  left: (thumbX - 10).clamp(0.0, w - 20),
                  child: Opacity(
                    opacity: widget.disabled ? 0.5 : 1,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(isDark ? 0.18 : 0.85),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 16,
                            color: Colors.black.withOpacity(isDark ? 0.30 : 0.12),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
