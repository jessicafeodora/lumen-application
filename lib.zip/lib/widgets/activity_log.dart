import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme/lumen_theme.dart';
import 'glass_card.dart';

class ActivityLogCard extends StatelessWidget {
  final List<ActivityEntry> entries;

  const ActivityLogCard({super.key, required this.entries});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? LumenColors.darkAccent : LumenColors.lightAccent;

    return GlassCard(
      size: GlassSize.md,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.history_rounded,
                  size: 20, color: (isDark ? Colors.white : Colors.black).withOpacity(0.45)),
              const SizedBox(width: 10),
              const Text("Activity", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 14),

          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 260),
            child: entries.isEmpty
                ? Center(
              child: Text(
                "No activity yet",
                style: TextStyle(
                  fontSize: 14,
                  color: (isDark ? Colors.white : Colors.black).withOpacity(0.55),
                  fontWeight: FontWeight.w700,
                ),
              ),
            )
                : ListView.separated(
              shrinkWrap: true,
              itemCount: entries.length,
              separatorBuilder: (_, __) => Divider(
                height: 18,
                color: Colors.white.withOpacity(isDark ? 0.10 : 0.20),
              ),
              itemBuilder: (context, i) {
                final e = entries[i];
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 7),
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(e.action, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(
                            e.timestamp,
                            style: TextStyle(
                              fontSize: 12,
                              color: (isDark ? Colors.white : Colors.black).withOpacity(0.55),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
