import 'package:flutter/material.dart';
import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/header.dart';

class SettingsPage extends StatelessWidget {
  final LampController controller;
  const SettingsPage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: LumenHeader(controller: controller, showSettings: false),
          body: LayoutBuilder(
            builder: (_, c) {
              final isDesktop = c.maxWidth >= 1024;
              final maxWidth = isDesktop ? 720.0 : double.infinity;
              final headerSpace = 84.0 + MediaQuery.of(context).padding.top;

              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: c.maxWidth < 640 ? 16 : 24,
                  vertical: 24,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: maxWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: headerSpace),

                        Text(
                          'Settings',
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Customize your Lúmen experience',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 20),

                        Glass(
                          size: GlassSize.md,
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            children: [
                              _row(
                                context,
                                icon: Icons.brightness_6_outlined,
                                title: 'Theme',
                                subtitle: 'Choose your preferred appearance',
                                trailing: DropdownButton<ThemeMode>(
                                  value: controller.themeMode,
                                  underline: const SizedBox.shrink(),
                                  onChanged: (v) {
                                    if (v != null) controller.setThemeMode(v);
                                  },
                                  items: const [
                                    DropdownMenuItem(value: ThemeMode.system, child: Text('System')),
                                    DropdownMenuItem(value: ThemeMode.light, child: Text('Light')),
                                    DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark')),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              _row(
                                context,
                                icon: Icons.flash_on_outlined,
                                title: 'Device Name',
                                subtitle: 'Customize your lamp name',
                                trailing: SizedBox(
                                  width: 180,
                                  child: TextFormField(
                                    initialValue: 'Living Room Lamp',
                                    decoration: const InputDecoration(isDense: true, border: InputBorder.none),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              _row(
                                context,
                                icon: Icons.flash_on_outlined,
                                title: 'Auto Off',
                                subtitle: 'Automatically turn off after 8 hours',
                                trailing: Switch(
                                  value: false,
                                  onChanged: (_) {},
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20),

                        Glass(
                          size: GlassSize.md,
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'ABOUT',
                                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Lúmen',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Version 1.0.0',
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Lúmen is a modern, glassmorphic lamp control interface designed for elegance and simplicity.\nControl your smart lamp with precision and style.',
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  height: 1.5,
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55),
                                ),
                              ),
                              const SizedBox(height: 22),
                              Center(
                                child: TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                                  child: const Text('Back to Dashboard   >'),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _row(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String subtitle,
        required Widget trailing,
      }) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55)),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        trailing,
      ],
    );
  }
}
