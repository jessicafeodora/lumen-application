import 'package:flutter/material.dart';
import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/widgets/activity_log.dart';
import 'package:lumen_application/widgets/brightness_slider.dart';
import 'package:lumen_application/widgets/connection_status.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/header.dart';
import 'package:lumen_application/widgets/mode_selector.dart';
import 'package:lumen_application/widgets/power_toggle.dart';
import 'package:lumen_application/widgets/timer_chips.dart';

class HomePage extends StatelessWidget {
  final LampController controller;
  const HomePage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return Scaffold(
          appBar: LumenHeader(controller: controller, showSettings: true),
          body: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              final isDesktop = w >= 1024;

              return Stack(
                children: [
                  SingleChildScrollView(
                    padding: EdgeInsets.fromLTRB(
                      w < 640 ? 16 : 24,
                      isDesktop ? 24 : 20,
                      w < 640 ? 16 : 24,
                      isDesktop ? 24 : 110,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1280),
                        child: isDesktop
                            ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(flex: 8, child: _LeftColumn(controller: controller, isDesktop: true)),
                            const SizedBox(width: 24),
                            Expanded(flex: 4, child: _RightColumn(controller: controller)),
                          ],
                        )
                            : _LeftColumn(controller: controller, isDesktop: false),
                      ),
                    ),
                  ),

                  if (!isDesktop)
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                        child: Glass(
                          size: GlassSize.md,
                          padding: const EdgeInsets.all(12),
                          borderRadius: BorderRadius.circular(22),
                          child: SafeArea(
                            top: false,
                            child: ConnectionStatusBar(
                              isConnected: controller.isConnected,
                              showOnlineRight: true,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _LeftColumn extends StatelessWidget {
  final LampController controller;
  final bool isDesktop;

  const _LeftColumn({required this.controller, required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    final pad = isDesktop ? 40.0 : 28.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Glass(
          size: GlassSize.lg,
          glow: controller.isOn, // ✅ fixed halo glow
          borderRadius: BorderRadius.circular(28),
          padding: EdgeInsets.all(pad),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Living Room Lamp',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                controller.isOn ? 'ON • ${controller.brightness}%' : 'OFF',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.45),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 22),

              PowerToggle(
                isOn: controller.isOn,
                label: 'Living Room',
                onToggle: controller.setPower,
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        LayoutBuilder(
          builder: (_, c) {
            final w = c.maxWidth;
            final twoCol = w >= 640;
            return Wrap(
              spacing: 20,
              runSpacing: 20,
              children: [
                SizedBox(
                  width: twoCol ? (w - 20) / 2 : w,
                  child: BrightnessCard(
                    value: controller.isOn ? controller.brightness : 0,
                    disabled: !controller.isOn,
                    onChanged: controller.setBrightness,
                  ),
                ),
                SizedBox(
                  width: twoCol ? (w - 20) / 2 : w,
                  child: TimerCard(
                    selectedMinutes: controller.timerMinutes,
                    onSelect: controller.setTimer,
                  ),
                ),
              ],
            );
          },
        ),

        const SizedBox(height: 20),

        ModeSelectorCard(
          selected: controller.mode,
          onSelect: controller.setMode,
        ),

        const SizedBox(height: 20),

        if (!isDesktop) const ActivityLogCard(entries: []),
      ],
    );
  }
}

class _RightColumn extends StatelessWidget {
  final LampController controller;
  const _RightColumn({required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.all(24),
          borderRadius: BorderRadius.circular(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Device Status',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 16),
              ConnectionStatusTile(
                isConnected: controller.isConnected,
                deviceName: 'ESP32-Lamp',
                lastUpdated: 'Just now',
              ),
              const SizedBox(height: 16),
              Divider(color: Colors.white.withValues(alpha: isDark ? 0.10 : 0.20)),
              const SizedBox(height: 16),
              _kv(context, 'Power Usage', controller.isOn ? '${controller.brightness}W' : '0W', accent: true),
              const SizedBox(height: 12),
              _kv(context, 'Uptime', '45d 2h'),
              const SizedBox(height: 12),
              _kv(context, 'Signal', controller.isConnected ? 'Strong' : 'Weak'),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const ActivityLogCard(entries: []),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v, {bool accent = false}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accentColor = isDark ? const Color(0xFF7DE3FF) : const Color(0xFFFFD36E);

    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.50),
            ),
          ),
        ),
        Text(
          v,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w800,
            color: accent ? accentColor : null,
          ),
        ),
      ],
    );
  }
}
