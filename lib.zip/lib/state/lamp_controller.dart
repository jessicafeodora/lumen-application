import 'dart:async';
import 'package:flutter/material.dart';

class LampController extends ChangeNotifier {
  bool isOn = false;
  int brightness = 75;
  String mode = 'normal'; // normal, reading, night
  int? timerMinutes;
  bool isConnected = true;

  ThemeMode themeMode = ThemeMode.light;

  Timer? _connSim;

  LampController() {
    // Simulate connection flips (matches ZIP behavior)
    _connSim = Timer.periodic(const Duration(seconds: 5), (_) {
      // ~5% chance flip
      final r = (DateTime.now().microsecondsSinceEpoch % 100);
      if (r > 95) {
        isConnected = !isConnected;
        notifyListeners();
      }
    });
  }

  void toggleTheme() {
    themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    themeMode = mode;
    notifyListeners();
  }

  void setPower(bool v) {
    isOn = v;
    if (!isOn) {
      brightness = 0;
    } else {
      brightness = 75;
    }
    notifyListeners();
  }

  void setBrightness(int v) {
    brightness = v.clamp(0, 100);
    notifyListeners();
  }

  void setMode(String v) {
    mode = v;
    notifyListeners();
  }

  void setTimer(int? minutes) {
    timerMinutes = minutes;
    notifyListeners();
  }

  @override
  void dispose() {
    _connSim?.cancel();
    super.dispose();
  }
}
