import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme/lumen_theme.dart';
import '../utils/responsive.dart';
import '../widgets/glass_card.dart';
import '../widgets/header.dart';

class SettingsScreen extends StatelessWidget {
  final AppState app;
  const SettingsScreen({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;

        return Scaffold(
          appBar: LumenHeader(routeName: "/settings"),
          body: LayoutBuilder(
            builder: (context, c) {
              final pad = pagePaddingForWidth(c.maxWidth);

              return Stack(
                children: [
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: isDark
                              ? [
                            LumenColors.darkBackground,
                            const Color(0xFF0B2746),
                            const Color(0xFF081F39),
                          ]
                              : [
                            LumenColors.lightBackground,
                            const Color(0xFFF2EFE7),
                            const Color(0xFFEAE6DA),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    padding: pad,
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 720),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 8),
                            const Text(
                              "Settings",
                              style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Customize your Lúmen experience",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: (isDark ? Colors.white : Colors.black).withOpacity(0.60),
                              ),
                            ),
                            const SizedBox(height: 22),

                            _SectionTitle("GENERAL"),
                            const SizedBox(height: 12),

                            _SettingRow(
                              icon: isDark ? Icons.nightlight_round : Icons.wb_sunny_rounded,
                              iconColor: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                              title: "Theme",
                              subtitle: "Choose your preferred appearance",
                              trailing: _ThemeDropdown(
                                value: app.themePref,
                                onChanged: app.setThemePref,
                              ),
                            ),
                            const SizedBox(height: 12),

                            _SettingRow(
                              icon: Icons.bolt_rounded,
                              iconColor: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                              title: "Device Name",
                              subtitle: "Customize your lamp name",
                              trailing: _DeviceNameField(
                                value: app.deviceName,
                                onChanged: app.setDeviceName,
                              ),
                            ),
                            const SizedBox(height: 12),

                            _SettingRow(
                              icon: Icons.bolt_rounded,
                              iconColor: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                              title: "Auto Off",
                              subtitle: "Automatically turn off after 8 hours",
                              trailing: _ToggleSwitch(
                                value: app.autoOff,
                                onChanged: app.setAutoOff,
                              ),
                            ),

                            const SizedBox(height: 22),
                            _SectionTitle("ABOUT"),
                            const SizedBox(height: 12),

                            GlassCard(
                              size: GlassSize.md,
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Icon(
                                        Icons.info_outline_rounded,
                                        size: 22,
                                        color: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              "Lúmen",
                                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              "Version 1.0.0",
                                              style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                                color: (isDark ? Colors.white : Colors.black).withOpacity(0.60),
                                              ),
                                            ),
                                            const SizedBox(height: 10),
                                            Text(
                                              "Lúmen is a modern, glassmorphic lamp control interface designed for elegance and simplicity. Control your smart lamp with precision and style.",
                                              style: TextStyle(
                                                fontSize: 12,
                                                height: 1.4,
                                                fontWeight: FontWeight.w600,
                                                color: (isDark ? Colors.white : Colors.black).withOpacity(0.60),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 14),
                                  Divider(color: Colors.white.withOpacity(isDark ? 0.10 : 0.20)),
                                  const SizedBox(height: 12),
                                  const _AboutRow(k: "Device", v: "ESP32-Lamp"),
                                  const SizedBox(height: 8),
                                  const _AboutRow(k: "Firmware", v: "2.1.0"),
                                  const SizedBox(height: 8),
                                  const _AboutRow(k: "Last Update", v: "2 hours ago"),
                                ],
                              ),
                            ),

                            const SizedBox(height: 18),

                            GlassCard(
                              size: GlassSize.md,
                              interactive: true,
                              padding: const EdgeInsets.all(14),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(20),
                                onTap: () => Navigator.of(context).pushNamedAndRemoveUntil("/", (_) => false),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text(
                                      "Back to Dashboard",
                                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900),
                                    ),
                                    const SizedBox(width: 10),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      size: 18,
                                      color: (isDark ? Colors.white : Colors.black).withOpacity(0.75),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 22),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Text(
      text,
      style: TextStyle(
        fontSize: 12,
        letterSpacing: 1.6,
        fontWeight: FontWeight.w900,
        color: (isDark ? Colors.white : Colors.black).withOpacity(0.55),
      ),
    );
  }
}

class _SettingRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Widget trailing;

  const _SettingRow({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GlassCard(
      size: GlassSize.md,
      interactive: true,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Icon(icon, size: 22, color: iconColor),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: (isDark ? Colors.white : Colors.black).withOpacity(0.55),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          trailing,
        ],
      ),
    );
  }
}

class _ThemeDropdown extends StatelessWidget {
  final ThemeModePref value;
  final ValueChanged<ThemeModePref> onChanged;

  const _ThemeDropdown({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(isDark ? 0.12 : 0.20)),
        color: Colors.transparent,
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<ThemeModePref>(
          value: value,
          dropdownColor: Theme.of(context).colorScheme.surface,
          items: const [
            DropdownMenuItem(value: ThemeModePref.light, child: Text("Light")),
            DropdownMenuItem(value: ThemeModePref.dark, child: Text("Dark")),
            DropdownMenuItem(value: ThemeModePref.system, child: Text("System")),
          ],
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
        ),
      ),
    );
  }
}

class _DeviceNameField extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;

  const _DeviceNameField({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SizedBox(
      width: 220,
      child: TextFormField(
        initialValue: value,
        onChanged: onChanged,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
        decoration: InputDecoration(
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          filled: false,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.white.withOpacity(isDark ? 0.12 : 0.20)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: (isDark ? LumenColors.darkAccent : LumenColors.lightAccent).withOpacity(0.9),
            ),
          ),
        ),
      ),
    );
  }
}

class _ToggleSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleSwitch({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? LumenColors.darkAccent : LumenColors.lightAccent;

    return GestureDetector(
      onTap: () => onChanged(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        width: 46,
        height: 26,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          color: value ? accent.withOpacity(0.9) : Colors.white.withOpacity(isDark ? 0.15 : 0.20),
        ),
        child: Align(
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: 18,
            height: 18,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class _AboutRow extends StatelessWidget {
  final String k;
  final String v;
  const _AboutRow({required this.k, required this.v});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: (isDark ? Colors.white : Colors.black).withOpacity(0.55),
            ),
          ),
        ),
        Text(v, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
      ],
    );
  }
}
