import 'package:flutter/material.dart';

import '../state/lamp_controller.dart';
import '../theme/lumen_theme.dart';
import '../utils/responsive.dart';
import '../widgets/activity_log.dart';
import '../widgets/brightness_slider.dart';
import '../widgets/connection_status.dart';
import '../widgets/glass_card.dart';
import '../widgets/header.dart';
import '../widgets/mode_selector.dart';
import '../widgets/power_toggle.dart';
import '../widgets/timer_chips.dart';

class HomeScreen extends StatelessWidget {
  final LampController controller;
  const HomeScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;

        return Scaffold(
          appBar: LumenHeader(
            routeName: "/",
            onTapSettings: () => Navigator.of(context).pushNamed('/settings'),
            onToggleTheme: controller.toggleTheme,
          ),
          body: LayoutBuilder(
            builder: (context, c) {
              final layout = layoutForWidth(c.maxWidth);
              final pad = pagePaddingForWidth(c.maxWidth);

              return Stack(
                children: [
                  // Background gradient
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: isDark
                              ? [
                            LumenColors.darkBackground,
                            const Color(0xFF0B2746),
                            const Color(0xFF081F39),
                          ]
                              : [
                            LumenColors.lightBackground,
                            const Color(0xFFF2EFE7),
                            const Color(0xFFEAE6DA),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Content
                  SingleChildScrollView(
                    padding: EdgeInsets.only(
                      left: pad.left,
                      right: pad.right,
                      top: pad.top,
                      bottom: layout == LumenLayout.desktop ? pad.bottom : (pad.bottom + 96),
                    ),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 1280),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: _Body(layout: layout, controller: controller),
                      ),
                    ),
                  ),

                  // Mobile bottom status bar (use existing ConnectionStatusBar)
                  if (layout != LumenLayout.desktop)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                        child: GlassCard(
                          size: GlassSize.sm,
                          radiusOverride: BorderRadius.circular(18),
                          disableTopHighlight: true,
                          padding: const EdgeInsets.all(14),
                          child: SafeArea(
                            top: false,
                            child: ConnectionStatusBar(
                              isConnected: controller.isConnected,
                              showOnlineRight: true,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _Body extends StatelessWidget {
  final LumenLayout layout;
  final LampController controller;
  const _Body({required this.layout, required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (layout == LumenLayout.desktop) {
      // Desktop: 2 columns (8/12 + 4/12)
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _HeroCard(controller: controller),
                const SizedBox(height: 20),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: BrightnessCard(
                        value: controller.isOn ? controller.brightness : 0,
                        disabled: !controller.isOn,
                        onChanged: controller.setBrightness,
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: TimerCard(
                        selectedMinutes: controller.timerMinutes,
                        onSelect: controller.setTimer,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                ModeSelectorCard(
                  selected: controller.mode,      // String
                  onSelect: controller.setMode,   // String
                ),

                const SizedBox(height: 20),
                // (React/ZIP: activity is on right in desktop)
              ],
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Device Status
                GlassCard(
                  size: GlassSize.md,
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Device Status", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 12),
                      ConnectionStatusTile(
                        isConnected: controller.isConnected,
                        deviceName: "ESP32-Lamp",
                        lastUpdated: "Just now",
                      ),
                      const SizedBox(height: 14),
                      Divider(color: Colors.white.withValues(alpha: isDark ? 0.10 : 0.20)),
                      const SizedBox(height: 12),
                      _KeyValueRow(
                        k: "Power Usage",
                        v: "${controller.isOn ? controller.brightness : 0}W",
                        icon: Icons.bolt_rounded,
                        iconColor: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
                      ),
                      const SizedBox(height: 10),
                      const _KeyValueRow(k: "Uptime", v: "45d 2h"),
                      const SizedBox(height: 10),
                      _KeyValueRow(k: "Signal", v: controller.isConnected ? "Strong" : "Weak"),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Safety reminder
                GlassCard(
                  size: GlassSize.md,
                  padding: const EdgeInsets.all(18),
                  borderOverride: Border.all(
                    color: (isDark ? Colors.yellowAccent : Colors.orange).withValues(alpha: isDark ? 0.12 : 0.20),
                    width: 1,
                  ),
                  tintOverride: (isDark ? Colors.yellow.shade200 : Colors.yellow.shade100).withValues(alpha: 0.06),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "SAFETY REMINDER",
                        style: TextStyle(
                          fontSize: 12,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.w900,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "This lamp operates on high voltage AC. Ensure proper installation and keep away from moisture.",
                        style: TextStyle(
                          fontSize: 12,
                          height: 1.4,
                          color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.60),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Activity log (desktop right)
                const ActivityLogCard(entries: []),
              ],
            ),
          ),
        ],
      );
    }

    // Tablet/Mobile: stacked
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _HeroCard(controller: controller),
        const SizedBox(height: 18),

        if (layout == LumenLayout.tablet)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: BrightnessCard(
                  value: controller.isOn ? controller.brightness : 0,
                  disabled: !controller.isOn,
                  onChanged: controller.setBrightness,
                ),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: TimerCard(
                  selectedMinutes: controller.timerMinutes,
                  onSelect: controller.setTimer,
                ),
              ),
            ],
          )
        else ...[
          BrightnessCard(
            value: controller.isOn ? controller.brightness : 0,
            disabled: !controller.isOn,
            onChanged: controller.setBrightness,
          ),
          const SizedBox(height: 18),
          TimerCard(
            selectedMinutes: controller.timerMinutes,
            onSelect: controller.setTimer,
          ),
        ],

        const SizedBox(height: 18),

        ModeSelectorCard(
          selected: controller.mode,
          onSelect: controller.setMode,
        ),

        const SizedBox(height: 18),

        // Device + Safety + Logs
        GlassCard(
          size: GlassSize.md,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Device Status", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              ConnectionStatusTile(
                isConnected: controller.isConnected,
                deviceName: "ESP32-Lamp",
                lastUpdated: "Just now",
              ),
              const SizedBox(height: 14),
              Divider(color: Colors.white.withValues(alpha: isDark ? 0.10 : 0.20)),
              const SizedBox(height: 12),
              _KeyValueRow(
                k: "Power Usage",
                v: "${controller.isOn ? controller.brightness : 0}W",
                icon: Icons.bolt_rounded,
                iconColor: isDark ? LumenColors.darkAccent : LumenColors.lightAccent,
              ),
              const SizedBox(height: 10),
              const _KeyValueRow(k: "Uptime", v: "45d 2h"),
              const SizedBox(height: 10),
              _KeyValueRow(k: "Signal", v: controller.isConnected ? "Strong" : "Weak"),
            ],
          ),
        ),

        const SizedBox(height: 18),

        GlassCard(
          size: GlassSize.md,
          padding: const EdgeInsets.all(18),
          borderOverride: Border.all(
            color: (isDark ? Colors.yellowAccent : Colors.orange).withValues(alpha: isDark ? 0.12 : 0.20),
            width: 1,
          ),
          tintOverride: (isDark ? Colors.yellow.shade200 : Colors.yellow.shade100).withValues(alpha: 0.06),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "SAFETY REMINDER",
                style: TextStyle(
                  fontSize: 12,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "This lamp operates on high voltage AC. Ensure proper installation and keep away from moisture.",
                style: TextStyle(
                  fontSize: 12,
                  height: 1.4,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.60),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 18),

        const ActivityLogCard(entries: []),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final LampController controller;
  const _HeroCard({required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Stack(
      children: [
        // Glow behind card when ON
        if (controller.isOn)
          Positioned.fill(
            child: IgnorePointer(
              child: Opacity(
                opacity: 0.30,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: const RadialGradient(
                      radius: 0.90,
                      colors: [
                        Color.fromRGBO(127, 227, 255, 0.30),
                        Color.fromRGBO(127, 227, 255, 0.00),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

        GlassCard(
          size: GlassSize.lg,
          glow: controller.isOn,
          padding: const EdgeInsets.all(26),
          radiusOverride: BorderRadius.circular(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Text(
                "Living Room Lamp",
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                controller.isOn ? "ON • ${controller.brightness}%" : "OFF",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
                ),
              ),
              const SizedBox(height: 18),
              PowerToggle(
                isOn: controller.isOn,
                label: "Living Room",
                onToggle: controller.setPower,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _KeyValueRow extends StatelessWidget {
  final String k;
  final String v;
  final IconData? icon;
  final Color? iconColor;

  const _KeyValueRow({required this.k, required this.v, this.icon, this.iconColor});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.55),
            ),
          ),
        ),
        if (icon != null) ...[
          Icon(icon, size: 16, color: (iconColor ?? Theme.of(context).colorScheme.primary)),
          const SizedBox(width: 6),
        ],
        Text(v, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
      ],
    );
  }
}
