import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LumenColors {
  // Light Mode
  static const lightBackground = Color(0xFFEFECE3);
  static const lightFg = Color(0xFF000000);
  static const lightPrimary = Color(0xFF4A70A9);
  static const lightSecondary = Color(0xFF8FABD4);
  static const lightAccent = Color(0xFFFFD36E);
  static const lightMuted = Color(0xFFE0DDD1);
  static const lightBorder = Color(0xFFE0DDD1);
  static const lightSurface = Color(0xFFFFFFFF);

  // Dark Mode
  static const darkBackground = Color(0xFF0C2B4E);
  static const darkFg = Color(0xFFF4F4F4);
  static const darkPrimary = Color(0xFF7DE3FF);
  static const darkSecondary = Color(0xFF1D546C);
  static const darkAccent = Color(0xFF7DE3FF);
  static const darkSurface = Color(0xFF1A3D64);
  static const darkSecondarySurface = Color(0xFF1D546C);
  static const darkMuted = Color(0xFF334455);
  static const darkBorder = Color(0xFF334455);
}

class LumenTheme {
  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: LumenColors.lightBackground,
      colorScheme: const ColorScheme.light(
        primary: LumenColors.lightPrimary,
        secondary: LumenColors.lightSecondary,
        surface: LumenColors.lightSurface,
        onSurface: LumenColors.lightFg,
        onPrimary: Colors.white,
      ),
    );

    return base.copyWith(
      textTheme: GoogleFonts.interTextTheme(base.textTheme),
      primaryTextTheme: GoogleFonts.interTextTheme(base.primaryTextTheme),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
    );
  }

  static ThemeData get dark {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: LumenColors.darkBackground,
      colorScheme: const ColorScheme.dark(
        primary: LumenColors.darkPrimary,
        secondary: LumenColors.darkSecondary,
        surface: LumenColors.darkSurface,
        onSurface: LumenColors.darkFg,
      ),
    );

    return base.copyWith(
      textTheme: GoogleFonts.interTextTheme(base.textTheme),
      primaryTextTheme: GoogleFonts.interTextTheme(base.primaryTextTheme),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
    );
  }
}
