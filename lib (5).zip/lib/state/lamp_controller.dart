import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:lumen_application/services/rtdb_service.dart';
import 'package:lumen_application/services/activity_rtdb.dart';

class LampController extends ChangeNotifier {
  // =========================
  // UI state
  // =========================
  bool isOn = false;
  int brightness = 75;
  String mode = 'normal'; // normal, reading, night
  int? timerMinutes;

  String deviceName = 'Living Room Lamp';

  bool isConnected = false;

  // Monitoring (from reported)
  String? fwVersion;
  DateTime? lastSeen;

  // Status
  bool deviceOnline = false;

  // Stable device id (used in DB path)
  final String deviceId = 'ESP32-Lamp';

  // Theme (app-wide)
  ThemeMode themeMode = ThemeMode.light;

  // =========================
  // RTDB refs (nullable-safe)
  // =========================
  DatabaseReference? _rootRef;
  DatabaseReference? _metaRef;
  DatabaseReference? _desiredRef;
  DatabaseReference? _reportedRef;

  late final DatabaseReference _connectedRef; // global
  StreamSubscription<DatabaseEvent>? _connSub;
  StreamSubscription<DatabaseEvent>? _metaSub;
  StreamSubscription<DatabaseEvent>? _desiredSub;
  StreamSubscription<DatabaseEvent>? _reportedSub;

  bool _applyingRemote = false;
  DateTime? _lastRemoteEventAt;

  // Optional: keep auth sub so controller auto-detach even if gate forgets
  StreamSubscription<User?>? _authSub;

  LampController() {
    _connectedRef = RTDBService.globalRef('.info/connected');

    // react to auth changes
    _authSub = FirebaseAuth.instance.authStateChanges().listen(onAuthChanged);

    // initial attach
    onAuthChanged(FirebaseAuth.instance.currentUser);
  }

  // =========================
  // Labels
  // =========================
  String get lastUpdatedLabel {
    final t = _lastRemoteEventAt;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  String get lastSeenLabel {
    final t = lastSeen;
    if (t == null) return '—';
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 5) return 'Just now';
    if (diff.inMinutes < 1) return '${diff.inSeconds}s ago';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  // =========================
  // Theme
  // =========================
  void toggleTheme() {
    themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }

  void setThemeMode(ThemeMode v) {
    themeMode = v;
    notifyListeners();
  }

  // =========================
  // Auth attach/detach
  // =========================
  void onAuthChanged(User? user) {
    // Always keep connection listener (global)
    _listenConnection();

    if (user == null) {
      // user logged out → detach device listeners
      _detachDevice();
      // optional: reset UI bits that should not persist across accounts
      isConnected = false;
      deviceOnline = false;
      fwVersion = null;
      lastSeen = null;
      _lastRemoteEventAt = null;
      notifyListeners();
      return;
    }

    _attachDevice();
  }

  void _attachDevice() {
    final root = RTDBService.deviceRoot(deviceId);
    if (root == null) {
      _detachDevice();
      return;
    }

    _rootRef = root;
    _metaRef = root.child('meta');
    _desiredRef = root.child('desired');
    _reportedRef = root.child('reported');

    _listenMeta();
    _listenDesired();
    _listenReported();

    _claimDeviceIfNeeded();
  }

  void _detachDevice() {
    _metaSub?.cancel();
    _desiredSub?.cancel();
    _reportedSub?.cancel();
    _metaSub = null;
    _desiredSub = null;
    _reportedSub = null;

    _rootRef = null;
    _metaRef = null;
    _desiredRef = null;
    _reportedRef = null;
  }

  // =========================
  // Listeners
  // =========================
  void _listenConnection() {
    _connSub?.cancel();
    _connSub = _connectedRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is bool) {
        isConnected = v;
        notifyListeners();
      }
    });
  }

  void _listenMeta() {
    _metaSub?.cancel();
    final ref = _metaRef;
    if (ref == null) return;

    _metaSub = ref.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      final name = v['name'];
      if (name is String && name.trim().isNotEmpty) {
        deviceName = name.trim();
      }

      notifyListeners();
    });
  }

  void _listenDesired() {
    _desiredSub?.cancel();
    final ref = _desiredRef;
    if (ref == null) return;

    _desiredSub = ref.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      _applyingRemote = true;
      try {
        final p = v['isOn'];
        final b = v['brightness'];
        final m = v['mode'];
        final t = v['timerMinutes'];

        if (p is bool) isOn = p;

        if (b is num) {
          brightness = b.toInt().clamp(0, 100);
        }

        if (m is String && m.trim().isNotEmpty) {
          mode = m.trim();
        }

        if (t == null) {
          timerMinutes = null;
        } else if (t is num) {
          timerMinutes = t.toInt();
        }

        _lastRemoteEventAt = DateTime.now();
        notifyListeners();
      } finally {
        _applyingRemote = false;
      }
    });
  }

  void _listenReported() {
    _reportedSub?.cancel();
    final ref = _reportedRef;
    if (ref == null) return;

    _reportedSub = ref.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      final fw = v['fwVersion'];
      if (fw is String && fw.trim().isNotEmpty) {
        fwVersion = fw.trim();
      }

      final seen = v['lastSeen'];
      if (seen is int && seen > 0) {
        lastSeen = DateTime.fromMillisecondsSinceEpoch(seen);
      }

      // optional: online heuristic
      deviceOnline = true;

      notifyListeners();
    });
  }

  // =========================
  // Write helpers
  // =========================
  Future<void> _writeDesired(Map<String, dynamic> patch) async {
    if (_applyingRemote) return;

    final ref = _desiredRef;
    if (ref == null) return; // ✅ safe when logged out

    try {
      await ref.update(patch);
      await ref.child('updatedAt').set(ServerValue.timestamp);
    } catch (_) {
      // ignore
    }
  }

  Future<void> _writeMeta(Map<String, dynamic> patch) async {
    final ref = _metaRef;
    if (ref == null) return;
    try {
      await ref.update(patch);
    } catch (_) {}
  }

  // =========================
  // User actions
  // =========================
  Future<void> setPower(bool v) async {
    isOn = v;
    if (!isOn) brightness = 0;
    if (isOn && brightness == 0) brightness = 75;

    notifyListeners();

    await _writeDesired({
      'isOn': isOn,
      'brightness': brightness,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: isOn ? 'Power ON' : 'Power OFF',
      actor: 'app',
    );
  }

  Future<void> setBrightness(int v) async {
    brightness = v.clamp(0, 100);
    if (brightness > 0) isOn = true;

    notifyListeners();

    await _writeDesired({
      'brightness': brightness,
      'isOn': isOn,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Brightness set to $brightness%',
      actor: 'app',
    );
  }

  Future<void> setMode(String v) async {
    mode = v;
    notifyListeners();

    await _writeDesired({'mode': mode});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Mode changed to $mode',
      actor: 'app',
    );
  }

  Future<void> setTimer(int? minutes) async {
    timerMinutes = minutes;
    notifyListeners();

    await _writeDesired({'timerMinutes': timerMinutes});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: timerMinutes == null ? 'Timer cleared' : 'Timer set to ${timerMinutes}m',
      actor: 'app',
    );
  }

  Future<void> setDeviceName(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (trimmed == deviceName) return;

    deviceName = trimmed;
    notifyListeners();

    await _writeMeta({'name': deviceName});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Device renamed to "$deviceName"',
      actor: 'app',
    );
  }

  // =========================
  // Claim device (optional safety)
  // =========================
  bool _claiming = false;

  Future<void> _claimDeviceIfNeeded() async {
    if (_claiming) return;
    _claiming = true;

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final meta = _metaRef;
      if (meta == null) return;

      final ownerRef = meta.child('ownerUid');

      final snap = await ownerRef.get();
      final owner = snap.value;

      if (owner == null || (owner is String && owner.trim().isEmpty)) {
        await ownerRef.set(user.uid);
      }
    } catch (_) {
      // ignore
    } finally {
      _claiming = false;
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _connSub?.cancel();
    _detachDevice();
    super.dispose();
  }
}
