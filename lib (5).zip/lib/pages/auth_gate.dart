import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'auth/auth_shell.dart';
import 'home_page.dart';
import '../state/lamp_controller.dart';

class AuthGate extends StatelessWidget {
  final LampController controller;
  const AuthGate({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const SizedBox.shrink();
        }

        final user = snap.data;
        if (user == null) {
          return AuthShell(controller: controller);
        }

        return HomePage(controller: controller);
      },
    );
  }
}
