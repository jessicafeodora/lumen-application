import 'dart:math' as math;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/header.dart';
import 'package:lumen_application/pages/splash_page.dart';
import 'package:lumen_application/pages/auth_gate.dart';

class SettingsPage extends StatefulWidget {
  final LampController controller;
  const SettingsPage({super.key, required this.controller});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _nameCtrl;

  static const double _contentInset = 22.0;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.controller.deviceName);
    widget.controller.addListener(_syncName);
  }

  void _syncName() {
    final current = widget.controller.deviceName;
    if (_nameCtrl.text != current) {
      _nameCtrl.value = _nameCtrl.value.copyWith(
        text: current,
        selection: TextSelection.collapsed(offset: current.length),
        composing: TextRange.empty,
      );
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_syncName);
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('You will need to sign in again to control your lamp.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Log out')),
        ],
      ),
    );

    if (ok != true) return;

    await FirebaseAuth.instance.signOut();
    if (!mounted) return;

    final controller = widget.controller;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => SplashPage(
          controller: controller,
          nextBuilder: () => AuthGate(controller: controller),
        ),
      ),
          (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;

    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          body: LayoutBuilder(
            builder: (context, constraints) {
              final screenW = constraints.maxWidth;
              final isDesktop = screenW >= 1024;

              final topSafe = MediaQuery.of(context).padding.top;
              const headerSide = 12.0;
              const headerTopGap = 8.0;
              const headerBottomGap = 55.0;

              final headerTop = topSafe + headerTopGap;
              final headerHeight = LumenHeader.cardHeight;
              final contentTopMin = headerTop + headerHeight + headerBottomGap;

              final horizontalPadding = screenW < 640 ? 16.0 : 24.0;
              final contentTop = math.max(isDesktop ? 24.0 : 20.0, contentTopMin);

              return Stack(
                children: [
                  Positioned.fill(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.fromLTRB(
                        horizontalPadding,
                        contentTop,
                        horizontalPadding,
                        32,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 980),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: _contentInset),
                                child: Text(
                                  'Settings',
                                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),

                              Glass(
                                size: GlassSize.md,
                                padding: const EdgeInsets.all(22),
                                borderRadius: BorderRadius.circular(22),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Device Name',
                                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    TextField(
                                      controller: _nameCtrl,
                                      onChanged: controller.setDeviceName,
                                      decoration: const InputDecoration(
                                        hintText: 'Living Room Lamp',
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 16),

                              Glass(
                                size: GlassSize.md,
                                padding: const EdgeInsets.all(22),
                                borderRadius: BorderRadius.circular(22),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        'Account',
                                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: _logout,
                                      child: const Text('Log out'),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 16),

                              Glass(
                                size: GlassSize.md,
                                borderRadius: BorderRadius.circular(22),
                                padding: EdgeInsets.zero,
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(22),
                                  onTap: () => Navigator.of(context).pop(), // ✅ no splash
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 18),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          'Back to Dashboard',
                                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        const Icon(Icons.chevron_right, size: 22),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  Positioned(
                    top: headerTop,
                    left: headerSide,
                    right: headerSide,
                    child: LumenHeader(
                      controller: controller,
                      showSettings: false,
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}
