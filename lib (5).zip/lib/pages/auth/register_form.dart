import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:lumen_application/widgets/primary_button.dart';
import 'package:lumen_application/widgets/hover_link.dart';
import 'package:lumen_application/services/user_profile_rtdb.dart';
import 'package:lumen_application/services/auth_persistence.dart';

class RegisterForm extends StatefulWidget {
  final VoidCallback onGoLogin;
  const RegisterForm({super.key, required this.onGoLogin});

  @override
  State<RegisterForm> createState() => _RegisterFormState();
}

class _RegisterFormState extends State<RegisterForm> {
  final _formKey = GlobalKey<FormState>();

  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _confirm = TextEditingController();

  bool _loading = false;
  String _error = '';

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _error = '');
    final ok = _formKey.currentState?.validate() ?? false;
    if (!ok) return;

    setState(() => _loading = true);

    try {
      await AuthPersistence.apply(rememberMe: true);
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email.text.trim().toLowerCase(),
        password: _pass.text,
      );

      final user = cred.user;
      if (user != null) {
        await UserProfileRTDB.ensureUserProfile(user);
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        setState(() => _error = 'Email already in use.');
      } else if (e.code == 'invalid-email') {
        setState(() => _error = 'Invalid email.');
      } else if (e.code == 'weak-password') {
        setState(() => _error = 'Password too weak.');
      } else {
        setState(() => _error = 'Register failed.');
      }
    } catch (_) {
      setState(() => _error = 'Register failed.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    final canSubmit = !_loading &&
        (_email.text.trim().isNotEmpty) &&
        (_pass.text.isNotEmpty) &&
        (_confirm.text.isNotEmpty);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Create account',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w900,
            letterSpacing: -0.3,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Register to sync your lamp settings.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: scheme.onSurface.withOpacity(0.62),
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 18),

        Form(
          key: _formKey,
          onChanged: () => setState(() {}),
          child: Column(
            children: [
              _Field(
                label: 'Email',
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                validator: (v) {
                  final s = (v ?? '').trim().toLowerCase();
                  if (s.isEmpty) return 'Email is required';
                  if (!s.contains('@')) return 'Invalid email';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              _Field(
                label: 'Password',
                controller: _pass,
                obscureText: true,
                validator: (v) {
                  final s = (v ?? '');
                  if (s.isEmpty) return 'Password is required';
                  if (s.length < 6) return 'Min 6 characters';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              _Field(
                label: 'Confirm password',
                controller: _confirm,
                obscureText: true,
                validator: (v) {
                  if ((v ?? '') != _pass.text) return 'Passwords do not match';
                  return null;
                },
              ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        Row(
          children: [
            Text(
              'Already have an account?',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: scheme.onSurface.withOpacity(0.70),
              ),
            ),
            const SizedBox(width: 8),
            HoverLink(
              text: 'Sign in',
              onTap: widget.onGoLogin,
            ),
          ],
        ),

        if (_error.isNotEmpty) ...[
          const SizedBox(height: 10),
          Text(
            _error,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w800,
              color: Colors.redAccent,
            ),
          ),
        ],

        const SizedBox(height: 14),

        PrimaryButton(
          text: 'Create account',
          enabled: canSubmit,
          loading: _loading,
          onTap: _submit,
        ),
      ],
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType? keyboardType;
  final bool obscureText;
  final String? Function(String?)? validator;

  const _Field({
    required this.label,
    required this.controller,
    this.keyboardType,
    this.obscureText = false,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
      ),
    );
  }
}
