import 'package:flutter/material.dart';
import 'package:lumen_application/state/lamp_controller.dart';
import 'package:lumen_application/utils/responsive.dart';
import 'package:lumen_application/widgets/glass.dart';

import 'login_form.dart';
import 'register_form.dart';

class AuthShell extends StatefulWidget {
  final LampController controller;
  const AuthShell({super.key, required this.controller});

  @override
  State<AuthShell> createState() => _AuthShellState();
}

class _AuthShellState extends State<AuthShell> {
  bool _isLogin = true;

  void _goRegister() => setState(() => _isLogin = false);
  void _goLogin() => setState(() => _isLogin = true);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final layout = layoutForWidth(width);

    return AnimatedBuilder(
      animation: widget.controller,
      builder: (_, __) {
        return Scaffold(
          body: _AuthBackground(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: (layout == LumenLayout.desktop)
                    ? _DesktopSplit(
                  controller: widget.controller,
                  isLogin: _isLogin,
                  onGoRegister: _goRegister,
                  onGoLogin: _goLogin,
                )
                    : _Stacked(
                  controller: widget.controller,
                  isLogin: _isLogin,
                  onGoRegister: _goRegister,
                  onGoLogin: _goLogin,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Background yang “lebih (4)”:
/// - deep blue gradient
/// - ada subtle glow
class _AuthBackground extends StatelessWidget {
  final Widget child;
  const _AuthBackground({required this.child});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    // Warna dasar yang bikin dark mode “biru dalam” (kayak (4)),
    // tapi tetep ngikutin theme surface biar konsisten.
    final deepA = const Color(0xFF07162E);
    final deepB = const Color(0xFF0B2A4D);
    final deepC = const Color(0xFF061022);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            // anchor yang bikin “gelap & biru”
            deepA,
            // campur theme surface supaya masih nyambung Lumen theme
            Color.alphaBlend(scheme.surface.withOpacity(0.25), deepB),
            deepC,
          ],
        ),
      ),
      child: Stack(
        children: [
          // subtle glow blob (biar ga flat)
          Positioned(
            left: -160,
            top: -140,
            child: _GlowBlob(
              color: scheme.primary.withOpacity(0.20),
              size: 380,
            ),
          ),
          Positioned(
            right: -190,
            bottom: -180,
            child: _GlowBlob(
              color: scheme.secondary.withOpacity(0.18),
              size: 420,
            ),
          ),
          child,
        ],
      ),
    );
  }
}

class _GlowBlob extends StatelessWidget {
  final Color color;
  final double size;
  const _GlowBlob({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
      ),
    );
  }
}

class _DesktopSplit extends StatelessWidget {
  final LampController controller;
  final bool isLogin;
  final VoidCallback onGoRegister;
  final VoidCallback onGoLogin;

  const _DesktopSplit({
    required this.controller,
    required this.isLogin,
    required this.onGoRegister,
    required this.onGoLogin,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Left: brand / marketing (kayak (4))
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 54),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 620),
                child: const _BrandLeft(),
              ),
            ),
          ),
        ),

        const SizedBox(width: 22),

        // Right: auth card
        SizedBox(
          width: 560,
          child: _AuthCard(
            controller: controller,
            isLogin: isLogin,
            onGoRegister: onGoRegister,
            onGoLogin: onGoLogin,
          ),
        ),
      ],
    );
  }
}

class _Stacked extends StatelessWidget {
  final LampController controller;
  final bool isLogin;
  final VoidCallback onGoRegister;
  final VoidCallback onGoLogin;

  const _Stacked({
    required this.controller,
    required this.isLogin,
    required this.onGoRegister,
    required this.onGoLogin,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Column(
          children: [
            const SizedBox(height: 10),
            const _BrandTopCompact(),
            const SizedBox(height: 18),
            _AuthCard(
              controller: controller,
              isLogin: isLogin,
              onGoRegister: onGoRegister,
              onGoLogin: onGoLogin,
            ),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }
}

class _AuthCard extends StatelessWidget {
  final LampController controller;
  final bool isLogin;
  final VoidCallback onGoRegister;
  final VoidCallback onGoLogin;

  const _AuthCard({
    required this.controller,
    required this.isLogin,
    required this.onGoRegister,
    required this.onGoLogin,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Glass(
      size: GlassSize.lg,
      borderRadius: BorderRadius.circular(28),
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _HeaderLogoRow(
            onTheme: controller.toggleTheme,
          ),
          const SizedBox(height: 14),

          // Tabs (Sign In / Create) seperti (4)
          _AuthTabs(
            isLogin: isLogin,
            onLogin: onGoLogin,
            onRegister: onGoRegister,
          ),

          const SizedBox(height: 18),

          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              isLogin ? 'Welcome back' : 'Create account',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
                letterSpacing: -0.2,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              isLogin
                  ? 'Sign in to control your lamp'
                  : 'Register to start controlling your lamp',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: scheme.onSurface.withOpacity(0.70),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 18),

          if (isLogin)
            LoginForm(onGoRegister: onGoRegister)
          else
            RegisterForm(onGoLogin: onGoLogin),
        ],
      ),
    );
  }
}

/// Tab bar yang “pill” + highlight
class _AuthTabs extends StatelessWidget {
  final bool isLogin;
  final VoidCallback onLogin;
  final VoidCallback onRegister;

  const _AuthTabs({
    required this.isLogin,
    required this.onLogin,
    required this.onRegister,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      height: 46,
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: scheme.surface.withOpacity(0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.onSurface.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _TabButton(
              selected: isLogin,
              text: 'Sign In',
              onTap: onLogin,
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: _TabButton(
              selected: !isLogin,
              text: 'Create',
              onTap: onRegister,
            ),
          ),
        ],
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  final bool selected;
  final String text;
  final VoidCallback onTap;

  const _TabButton({
    required this.selected,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: selected ? scheme.surface.withOpacity(0.22) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected
                ? scheme.onSurface.withOpacity(0.14)
                : Colors.transparent,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: Theme.of(context).textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w800,
            color: selected
                ? scheme.onSurface.withOpacity(0.92)
                : scheme.onSurface.withOpacity(0.65),
          ),
        ),
      ),
    );
  }
}

class _BrandLeft extends StatelessWidget {
  const _BrandLeft();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _LogoMark(size: 64),
        const SizedBox(height: 18),
        Text(
          'Lúmen',
          style: Theme.of(context).textTheme.displaySmall?.copyWith(
            fontWeight: FontWeight.w900,
            letterSpacing: -0.3,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Smart Home Lamp Control',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: scheme.onSurface.withOpacity(0.70),
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 14),
        Text(
          'Control power, brightness, modes, timers, and monitor device status with a clean glass UI.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: scheme.onSurface.withOpacity(0.62),
            height: 1.35,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _BrandTopCompact extends StatelessWidget {
  const _BrandTopCompact();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        const _LogoMark(size: 44),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Lúmen',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              'Smart Home Lamp Control',
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: scheme.onSurface.withOpacity(0.70),
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _HeaderLogoRow extends StatelessWidget {
  final VoidCallback onTheme;
  const _HeaderLogoRow({required this.onTheme});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        const _LogoMark(size: 40),
        const SizedBox(width: 10),
        Text(
          'Lúmen',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
          ),
        ),
        const Spacer(),
        IconButton.filledTonal(
          onPressed: onTheme,
          icon: const Icon(Icons.wb_sunny_outlined),
          tooltip: 'Theme',
        ),
      ],
    );
  }
}

/// Logo chip yang “mirip homepage/icon” (kuning → biru)
class _LogoMark extends StatelessWidget {
  final double size;
  const _LogoMark({required this.size});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFFD36E),
            Color(0xFF4A70A9),
            Color(0xFF8FABD4),
          ],
        ),
        border: Border.all(color: scheme.onSurface.withOpacity(0.10)),
      ),
      alignment: Alignment.center,
      child: Text(
        'L',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}
