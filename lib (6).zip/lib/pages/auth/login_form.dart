import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:lumen_application/widgets/primary_button.dart';
import 'package:lumen_application/widgets/hover_link.dart';
import 'package:lumen_application/services/auth_persistence.dart';

class LoginForm extends StatefulWidget {
  final VoidCallback onGoRegister;
  const LoginForm({super.key, required this.onGoRegister});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();

  final _email = TextEditingController();
  final _pass = TextEditingController();

  bool _loading = false;
  bool _remember = true;
  bool _showPass = false;
  String _error = '';

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  String? _validateEmail(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return 'Email is required';
    if (!s.contains('@')) return 'Invalid email';
    return null;
  }

  String? _validatePass(String? v) {
    final s = v ?? '';
    if (s.isEmpty) return 'Password is required';
    if (s.length < 6) return 'Min 6 characters';
    return null;
  }

  Future<void> _submit() async {
    setState(() => _error = '');
    final ok = _formKey.currentState?.validate() ?? false;
    if (!ok) return;

    setState(() => _loading = true);

    try {
      // Optional: remember-me persistence helper
      try {
        await AuthPersistence.apply(rememberMe: _remember);
      } catch (_) {}

      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(),
        password: _pass.text,
      );

      try {
        HapticFeedback.lightImpact();
      } catch (_) {}
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _friendlyAuthError(e));
      try {
        HapticFeedback.mediumImpact();
      } catch (_) {}
    } catch (_) {
      setState(() => _error = 'Something went wrong. Please try again.');
      try {
        HapticFeedback.mediumImpact();
      } catch (_) {}
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _friendlyAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'Invalid email.';
      case 'user-disabled':
        return 'This account is disabled.';
      case 'user-not-found':
        return 'No account found for this email.';
      case 'wrong-password':
        return 'Wrong password.';
      case 'invalid-credential':
        return 'Invalid credentials.';
      case 'too-many-requests':
        return 'Too many attempts. Try again later.';
      default:
        return e.message ?? 'Login failed.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Form(
      key: _formKey,
      child: Column(
        children: [
          _Field(
            label: 'Email',
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            validator: _validateEmail,
            enabled: !_loading,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pass,
            enabled: !_loading,
            obscureText: !_showPass,
            validator: _validatePass,
            decoration: InputDecoration(
              labelText: 'Password',
              suffixIcon: IconButton(
                onPressed: _loading ? null : () => setState(() => _showPass = !_showPass),
                icon: Icon(_showPass ? Icons.visibility_off : Icons.visibility),
                tooltip: _showPass ? 'Hide password' : 'Show password',
              ),
            ),
          ),
          const SizedBox(height: 10),

          Row(
            children: [
              Checkbox(
                value: _remember,
                onChanged: _loading ? null : (v) => setState(() => _remember = v ?? true),
              ),
              Text(
                'Remember me',
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: scheme.onSurface.withOpacity(0.75),
                ),
              ),
              const Spacer(),
              // Optional: forgot password (if you have it)
              // HoverLink(text: 'Forgot password?', onTap: () {}),
            ],
          ),

          const SizedBox(height: 14),

          SizedBox(
            width: double.infinity,
            height: 52,
            child: PrimaryButton(
              text: 'Sign In',
              enabled: !_loading,
              loading: _loading,
              onTap: _loading ? () {} : _submit,
            ),
          ),

          const SizedBox(height: 12),

          // Social login (UI only; wire up when packages are ready)
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: null, // TODO: Google Sign-In
                  icon: const Icon(Icons.g_mobiledata),
                  label: const Text('Google'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: null, // TODO: Facebook Sign-In
                  icon: const Icon(Icons.facebook),
                  label: const Text('Facebook'),
                ),
              ),
            ],
          ),

          if (_error.isNotEmpty) ...[
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                _error,
                style: theme.textTheme.labelMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: scheme.error.withOpacity(0.9),
                ),
              ),
            ),
          ],

          const SizedBox(height: 16),

          Row(
            children: [
              Text(
                "Don't have an account?",
                style: theme.textTheme.bodySmall?.copyWith(
                  color: scheme.onSurface.withOpacity(0.70),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              HoverLink(
                text: 'Create account',
                onTap: _loading ? () {} : widget.onGoRegister,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final bool enabled;

  const _Field({
    required this.label,
    required this.controller,
    required this.keyboardType,
    required this.validator,
    required this.enabled,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      enabled: enabled,
      decoration: InputDecoration(labelText: label),
    );
  }
}