import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lumen_application/utils/responsive.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/widgets/dot_loader.dart';

class SplashPage extends StatefulWidget {
  final Widget Function() nextBuilder;

  const SplashPage({
    super.key,
    required this.nextBuilder,
  });

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 850), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 320),
          pageBuilder: (_, anim, __) => FadeTransition(
            opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
            child: widget.nextBuilder(),
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final width = MediaQuery.of(context).size.width;
    final layout = layoutForWidth(width);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              scheme.surface,
              scheme.surfaceContainerHighest.withOpacity(0.72),
              scheme.surface.withOpacity(0.92),
            ],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: layout == LumenLayout.desktop
                ? ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: _Content(),
            )
                : const _Content(),
          ),
        ),
      ),
    );
  }
}

class _Content extends StatelessWidget {
  const _Content();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Glass(
      size: GlassSize.lg,
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 26),
      borderRadius: BorderRadius.circular(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _Mark(),
          const SizedBox(height: 16),
          Text(
            'Lúmen',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w900,
              letterSpacing: -0.2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Smart Home Lamp Control',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: scheme.onSurface.withOpacity(0.70),
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 18),
          const DotLoader(),
        ],
      ),
    );
  }
}

class _Mark extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFFD36E),
            Color(0xFF4A70A9),
            Color(0xFF8FABD4),
          ],
        ),
        border: Border.all(color: scheme.onSurface.withOpacity(0.10)),
      ),
      alignment: Alignment.center,
      child: const Text(
        'L',
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w900,
          color: Colors.white,
        ),
      ),
    );
  }
}
