import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../services/rtdb_service.dart';

class PairDevicePage extends StatefulWidget {
  const PairDevicePage({super.key});

  @override
  State<PairDevicePage> createState() => _PairDevicePageState();
}

class _PairDevicePageState extends State<PairDevicePage> {
  final _manual = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _pair(String deviceId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final id = deviceId.trim();
    if (id.isEmpty) return;

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      // 1) Save to user profile (multi-device ready)
      final userRef = RTDBService.globalRef('users/$uid');
      await userRef.child('devices/$id').set(true);
      await userRef.child('activeDeviceId').set(id);

      // 2) Claim ownerUid if empty
      final metaRef = RTDBService.globalRef('devices/$id/meta');
      final ownerRef = metaRef.child('ownerUid');

      await ownerRef.runTransaction((current) {
        if (current == null || (current is String && current.trim().isEmpty)) {
          return Transaction.success(uid);
        }
        return Transaction.abort();
      });

      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = 'Failed to pair device. (${e.runtimeType})');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _manual.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    return Scaffold(
      appBar: AppBar(title: const Text('Pair device')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: isWide
              ? Row(
            children: [
              Expanded(child: _scannerCard()),
              const SizedBox(width: 16),
              Expanded(child: _manualCard()),
            ],
          )
              : ListView(
            children: [
              _scannerCard(),
              const SizedBox(height: 16),
              _manualCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scannerCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Scan QR', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            AspectRatio(
              aspectRatio: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: MobileScanner(
                  onDetect: (capture) {
                    final codes = capture.barcodes;
                    if (codes.isEmpty) return;
                    final raw = codes.first.rawValue;
                    if (raw == null || raw.trim().isEmpty) return;

                    // Simple parse: QR contains the deviceId directly.
                    // If QR uses format "lumen://device/XYZ", parse accordingly.
                    final id = raw.trim().replaceAll('lumen://device/', '');
                    if (!_busy) _pair(id);
                  },
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'QR should contain your deviceId (example: ESP32-Lamp).',
              style: TextStyle(color: Colors.black.withOpacity(0.6)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _manualCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Manual', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            TextField(
              controller: _manual,
              decoration: const InputDecoration(
                labelText: 'Device ID',
                hintText: 'e.g. ESP32-Lamp',
              ),
            ),
            const SizedBox(height: 12),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            FilledButton(
              onPressed: _busy ? null : () => _pair(_manual.text),
              child: _busy ? const Text('Pairing...') : const Text('Pair device'),
            ),
          ],
        ),
      ),
    );
  }
}
