import 'dart:math' as math;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../state/lamp_controller.dart';
import '../widgets/glass.dart';
import '../widgets/header.dart';

class SettingsPage extends StatelessWidget {
  final LampController controller;

  const SettingsPage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return Scaffold(
          extendBodyBehindAppBar: true,
          body: LayoutBuilder(
            builder: (context, constraints) {
              final screenW = constraints.maxWidth;
              final isDesktop = screenW >= 1024;

              // ✅ Same floating header geometry as HomePage
              final topSafe = MediaQuery.of(context).padding.top;
              const headerSide = 12.0;
              const headerTopGap = 8.0;
              const headerBottomGap = 24.0;

              final headerTop = topSafe + headerTopGap;
              final headerHeight = LumenHeader.cardHeight;
              final contentTopMin = headerTop + headerHeight + headerBottomGap;

              final horizontalPadding = screenW < 640 ? 16.0 : 24.0;
              final bottomPadding = isDesktop ? 24.0 : 24.0;

              final contentTop = math.max(24.0, contentTopMin);

              return Stack(
                children: [
                  // ✅ Content (same scaffold style as HomePage)
                  Positioned.fill(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.fromLTRB(
                        horizontalPadding,
                        contentTop,
                        horizontalPadding,
                        bottomPadding,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 920),
                          child: _SettingsContent(controller: controller),
                        ),
                      ),
                    ),
                  ),

                  // ✅ EXACT same header widget as HomePage (logo + theme btn + glass)
                  Positioned(
                    top: headerTop,
                    left: headerSide,
                    right: headerSide,
                    child: LumenHeader(
                      controller: controller,
                      showSettings: false, // we're already on settings
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _SettingsContent extends StatelessWidget {
  final LampController controller;
  const _SettingsContent({required this.controller});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 6),

        Text(
          "Settings",
          style: theme.textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 8),
        Text(
          "Customize your Lúmen experience",
          style: theme.textTheme.titleMedium?.copyWith(
            color: theme.colorScheme.onSurface.withOpacity(0.70),
          ),
        ),

        const SizedBox(height: 22),

        if (controller.lastWriteFailed)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Text(
              'Some changes may not have been saved. Check your connection.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.error.withOpacity(0.90),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),


        const _SectionTitle("GENERAL"),
        const SizedBox(height: 14),

        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          borderRadius: BorderRadius.circular(22),
          child: Row(
            children: [
              Icon(Icons.wb_sunny_outlined, color: theme.colorScheme.primary.withOpacity(0.95)),
              const SizedBox(width: 14),
              Expanded(
                child: _TileTexts(
                  title: "Theme",
                  subtitle: "Choose your preferred appearance",
                ),
              ),
              _ThemeDropdown(
                value: controller.themeMode,
                onChanged: controller.setThemeMode,
              ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          borderRadius: BorderRadius.circular(22),
          child: Row(
            children: [
              Icon(Icons.bolt, color: theme.colorScheme.primary.withOpacity(0.95)),
              const SizedBox(width: 14),
              const Expanded(
                child: _TileTexts(
                  title: "Device Name",
                  subtitle: "Customize your lamp name",
                ),
              ),
              SizedBox(
                width: 260,
                child: _DeviceNameField(
                  initialValue: controller.deviceName,
                  onChanged: controller.setDeviceName,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        Glass(
          size: GlassSize.md,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          borderRadius: BorderRadius.circular(22),
          child: Row(
            children: [
              Icon(Icons.bolt, color: theme.colorScheme.primary.withOpacity(0.95)),
              const SizedBox(width: 14),
              const Expanded(
                child: _TileTexts(
                  title: "Auto Off",
                  subtitle: "Automatically turn off after 8 hours",
                ),
              ),
              Switch(
                value: controller.autoOff,
                onChanged: (v) => controller.setAutoOff(v),
              ),
            ],
          ),
        ),

        const SizedBox(height: 24),

        const _SectionTitle("ACCOUNT"),
        const SizedBox(height: 14),

        Glass(
          size: GlassSize.lg,
          padding: const EdgeInsets.all(22),
          borderRadius: BorderRadius.circular(22),
          child: Builder(
            builder: (context) {
              final user = FirebaseAuth.instance.currentUser;
              final email = user?.email ?? '—';
              final name = (user?.displayName?.trim().isNotEmpty ?? false)
                  ? user!.displayName!.trim()
                  : 'User';

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Signed in",
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),

                  Row(
                    children: [
                      CircleAvatar(
                        radius: 18,
                        child: Text(name.isNotEmpty ? name[0].toUpperCase() : "U"),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              name,
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              email,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.70),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),
                  Divider(color: Colors.white.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.10 : 0.20)),
                  const SizedBox(height: 16),

                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          "Sign out from this device",
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.70),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      FilledButton.tonal(
                        onPressed: controller.isSigningOut ? null : () => _confirmLogout(context),
                        child: controller.isSigningOut
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text("Log out"),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),


        const SizedBox(height: 18),



        const SizedBox(height: 24),

        const _SectionTitle("ABOUT"),
        const SizedBox(height: 14),

        Glass(
          size: GlassSize.lg,
          padding: const EdgeInsets.all(22),
          borderRadius: BorderRadius.circular(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.info_outline, color: theme.colorScheme.primary.withOpacity(0.95)),
                  const SizedBox(width: 12),
                  Text(
                    "Lúmen",
                    style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                "Version 1.0.0",
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.65),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                "Lúmen is a modern, glassmorphic lamp control interface designed for elegance and simplicity.\n"
                    "Control your smart lamp with precision and style.",
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.75),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 16),
              Divider(color: Colors.white.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.10 : 0.20)),
              const SizedBox(height: 12),
              _kv(context, "Device", (controller.deviceId ?? '—')),
              const SizedBox(height: 10),
              _kv(context, "Firmware", controller.fwVersion ?? "—"),
              const SizedBox(height: 10),
              _kv(context, "Last Update", controller.lastUpdatedLabel),
            ],
          ),
        ),

        const SizedBox(height: 24),

        SizedBox(
          width: double.infinity,
          height: 60,
          child: Glass(
            size: GlassSize.md,
            padding: const EdgeInsets.all(0),
            borderRadius: BorderRadius.circular(22),
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => Navigator.of(context).pop(),
              child: const Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Back to Dashboard"),
                    SizedBox(width: 10),
                    Icon(Icons.chevron_right),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          child: Text(
            k,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurface.withOpacity(0.50),
            ),
          ),
        ),
        Text(
          v,
          style: theme.textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Future<void> _confirmLogout(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Log out?"),
        content: const Text("You will need to sign in again to control your lamp."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Cancel")),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text("Log out")),
        ],
      ),
    );

    if (ok != true) return;

    await controller.signOutGracefully();
    if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Text(
      text,
      style: theme.textTheme.labelLarge?.copyWith(
        letterSpacing: 1.4,
        color: theme.colorScheme.onSurface.withOpacity(0.72),
        fontWeight: FontWeight.w900,
      ),
    );
  }
}

class _TileTexts extends StatelessWidget {
  final String title;
  final String subtitle;
  const _TileTexts({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurface.withOpacity(0.70),
          ),
        ),
      ],
    );
  }
}

class _DeviceNameField extends StatefulWidget {
  final String initialValue;
  final ValueChanged<String> onChanged;

  const _DeviceNameField({required this.initialValue, required this.onChanged});

  @override
  State<_DeviceNameField> createState() => _DeviceNameFieldState();
}

class _DeviceNameFieldState extends State<_DeviceNameField> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return TextField(
      controller: _c,
      onChanged: widget.onChanged,
      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w800),
      decoration: InputDecoration(
        isDense: true,
        filled: true,
        fillColor: Colors.white.withOpacity(isDark ? 0.08 : 0.10),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(isDark ? 0.10 : 0.16)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(isDark ? 0.10 : 0.16)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: theme.colorScheme.primary.withOpacity(0.55)),
        ),
      ),
    );
  }
}

class _ThemeDropdown extends StatelessWidget {
  final ThemeMode value;
  final ValueChanged<ThemeMode> onChanged;

  const _ThemeDropdown({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton<ThemeMode>(
        value: value,
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
        items: const [
          DropdownMenuItem(value: ThemeMode.system, child: Text("System")),
          DropdownMenuItem(value: ThemeMode.light, child: Text("Light")),
          DropdownMenuItem(value: ThemeMode.dark, child: Text("Dark")),
        ],
      ),
    );
  }
}
