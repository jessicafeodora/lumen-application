import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

class RTDBService {
  RTDBService._();

  static const String dbUrl =
      'https://smart-home-lamp-d68de-default-rtdb.firebaseio.com';

  static FirebaseDatabase db() {
    return FirebaseDatabase.instanceFor(
      app: Firebase.app(),
      databaseURL: dbUrl,
    );
  }

  /// Current uid (null = not authenticated)
  static String? get uid => FirebaseAuth.instance.currentUser?.uid;

  /// users/{uid}
  static DatabaseReference? userRoot() {
    final u = uid;
    if (u == null) return null;
    return db().ref('users/$u');
  }

  /// users/{uid}/devices/{deviceId}
  static DatabaseReference? deviceRoot(String deviceId) {
    final root = userRoot();
    if (root == null) return null;
    return root.child('devices/$deviceId');
  }

  /// users/{uid}/{path}
  static DatabaseReference? ref(String path) {
    final root = userRoot();
    if (root == null) return null;
    return root.child(path);
  }

  /// Global ref (no uid needed) — use for .info/connected
  static DatabaseReference globalRef(String path) {
    return db().ref(path);
  }
}
