import 'package:firebase_database/firebase_database.dart';
import 'rtdb_service.dart';

class ActivityEntry {
  final String id;
  final String action;
  final String actor; // "app" | "device"
  final DateTime createdAt;

  ActivityEntry({
    required this.id,
    required this.action,
    required this.actor,
    required this.createdAt,
  });

  String get timestampLabel {
    String two(int x) => x.toString().padLeft(2, '0');
    return '${createdAt.year}-${two(createdAt.month)}-${two(createdAt.day)}  '
        '${two(createdAt.hour)}:${two(createdAt.minute)}';
  }
}

class ActivityRTDB {
  /// write log (user-scoped under device)
  static Future<void> add({
    required String deviceId,
    required String action,
    String actor = 'app',
  }) async {
    final root = RTDBService.deviceRoot(deviceId);
    if (root == null) return; // ✅ safe if logged out

    final ref = root.child('activity').push();
    await ref.set({
      'action': action,
      'actor': actor,
      'createdAt': ServerValue.timestamp,
    });
  }

  /// realtime stream (latest N)
  static Stream<List<ActivityEntry>> stream({
    required String deviceId,
    int limit = 20,
  }) {
    final root = RTDBService.deviceRoot(deviceId);
    if (root == null) {
      // ✅ if not authenticated → return empty stream (no crash)
      return Stream.value(const <ActivityEntry>[]);
    }

    final query = root
        .child('activity')
        .orderByChild('createdAt')
        .limitToLast(limit);

    return query.onValue.map((event) {
      final data = event.snapshot.value;
      if (data is! Map) return <ActivityEntry>[];

      final entries = <ActivityEntry>[];

      data.forEach((k, v) {
        if (v is Map) {
          final action = (v['action'] ?? '').toString();
          final actor = (v['actor'] ?? 'app').toString();
          final createdAtRaw = v['createdAt'];

          final ms = createdAtRaw is int ? createdAtRaw : 0;

          entries.add(
            ActivityEntry(
              id: k.toString(),
              action: action,
              actor: actor,
              createdAt: ms > 0
                  ? DateTime.fromMillisecondsSinceEpoch(ms)
                  : DateTime.now(),
            ),
          );
        }
      });

      entries.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return entries;
    });
  }
}
