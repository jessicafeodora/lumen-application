import 'package:firebase_database/firebase_database.dart';
import 'rtdb_service.dart';

class ActivityEntry {
  final String id;
  final String action;
  final DateTime createdAt;

  ActivityEntry({
    required this.id,
    required this.action,
    required this.createdAt,
  });

  String get timestampLabel {
    String two(int x) => x.toString().padLeft(2, '0');
    return '${createdAt.year}-${two(createdAt.month)}-${two(createdAt.day)}  '
        '${two(createdAt.hour)}:${two(createdAt.minute)}';
  }
}

class ActivityRTDB {
  // write log
  static Future<void> add({
    required String deviceId,
    required String action,
  }) async {
    final ref = RTDBService.ref('devices/$deviceId/activity').push();
    await ref.set({
      'action': action,
      'createdAt': ServerValue.timestamp, // RTDB server timestamp
    });
  }

  // realtime stream (latest N)
  static Stream<List<ActivityEntry>> stream({
    required String deviceId,
    int limit = 20,
  }) {
    final query = RTDBService
        .ref('devices/$deviceId/activity')
        .orderByChild('createdAt')
        .limitToLast(limit);

    return query.onValue.map((event) {
      final data = event.snapshot.value;

      if (data is! Map) return <ActivityEntry>[];

      final entries = <ActivityEntry>[];

      data.forEach((k, v) {
        if (v is Map) {
          final action = (v['action'] ?? '').toString();
          final createdAtRaw = v['createdAt'];

          // createdAt might be int (ms) or null briefly
          final ms = createdAtRaw is int ? createdAtRaw : 0;

          entries.add(
            ActivityEntry(
              id: k.toString(),
              action: action,
              createdAt: ms > 0 ? DateTime.fromMillisecondsSinceEpoch(ms) : DateTime.now(),
            ),
          );
        }
      });

      // sort newest first
      entries.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return entries;
    });
  }
}
