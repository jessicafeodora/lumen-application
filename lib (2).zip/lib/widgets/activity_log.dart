import 'package:flutter/material.dart';
import 'package:lumen_application/widgets/glass.dart';
import 'package:lumen_application/theme/lumen_theme.dart';
import 'package:lumen_application/services/activity_rtdb.dart';

class ActivityLogCard extends StatelessWidget {
  final List<ActivityEntry> entries;

  const ActivityLogCard({super.key, required this.entries});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = isDark ? LumenColors.darkAccent : LumenColors.lightAccent;

    final mutedIcon = Theme.of(context).colorScheme.onSurface.withOpacity(0.45);
    final mutedText = Theme.of(context).colorScheme.onSurface.withOpacity(0.55);
    final dividerColor = Colors.white.withOpacity(isDark ? 0.10 : 0.20);

    return Glass(
      size: GlassSize.md,
      padding: const EdgeInsets.all(24),
      borderRadius: BorderRadius.circular(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.history_rounded, size: 20, color: mutedIcon),
              const SizedBox(width: 10),
              Text(
                "Activity",
                style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 18),

          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 260),
            child: entries.isEmpty
                ? Center(
              child: Text(
                "No activity yet",
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: mutedText,
                ),
              ),
            )
                : ListView.separated(
              shrinkWrap: true,
              itemCount: entries.length,
              separatorBuilder: (_, __) => Divider(height: 18, color: dividerColor),
              itemBuilder: (context, i) {
                final e = entries[i];
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 7),
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            e.action,
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            e.timestampLabel,
                            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: mutedText,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
