import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:lumen_application/services/rtdb_service.dart';
import 'package:lumen_application/services/activity_rtdb.dart';

class LampController extends ChangeNotifier {
  // ------- Local UI state -------
  bool isOn = false;
  int brightness = 75;
  String mode = 'normal'; // normal, reading, night
  int? timerMinutes;
  bool isConnected = true;

  // Stable ID for Firebase paths (DO NOT change on rename)
  final String deviceId = 'ESP32-Lamp';

  // User-editable name (used in UI)
  String deviceName = 'Living Room Lamp';

  ThemeMode themeMode = ThemeMode.light;

  // ------- RTDB wiring -------
  late final DatabaseReference _deviceRef;
  StreamSubscription<DatabaseEvent>? _deviceSub;

  bool _applyingRemote = false; // prevents write-back loops

  // ------- Optional connection simulator -------
  Timer? _connSim;

  LampController() {
    _deviceRef = RTDBService.ref('devices/$deviceId');

    // Start listening to RTDB device state
    _listenToDevice();

    // Optional: keep your “connection flip” simulation,
    // BUT only as a fallback if RTDB doesn't provide status.
    _connSim = Timer.periodic(const Duration(seconds: 5), (_) {
      // ~5% chance flip
      final r = (DateTime.now().microsecondsSinceEpoch % 100);
      if (r > 95) {
        isConnected = !isConnected;
        notifyListeners();
      }
    });
  }

  // -------------------------
  // Firebase realtime listeners
  // -------------------------
  void _listenToDevice() {
    _deviceSub?.cancel();
    _deviceSub = _deviceRef.onValue.listen((event) {
      final v = event.snapshot.value;
      if (v is! Map) return;

      _applyingRemote = true;
      try {
        // Read fields safely
        final remotePower = v['isOn'];
        final remoteBrightness = v['brightness'];
        final remoteMode = v['mode'];
        final remoteTimer = v['timerMinutes'];
        final remoteConnected = v['isConnected'];
        final remoteName = v['deviceName'];

        if (remotePower is bool) isOn = remotePower;

        if (remoteBrightness is int) {
          brightness = remoteBrightness.clamp(0, 100);
        } else if (remoteBrightness is num) {
          brightness = remoteBrightness.toInt().clamp(0, 100);
        }

        if (remoteMode is String && remoteMode.isNotEmpty) {
          mode = remoteMode;
        }

        if (remoteTimer == null) {
          timerMinutes = null;
        } else if (remoteTimer is int) {
          timerMinutes = remoteTimer;
        } else if (remoteTimer is num) {
          timerMinutes = remoteTimer.toInt();
        }

        if (remoteConnected is bool) {
          isConnected = remoteConnected;
        }

        if (remoteName is String && remoteName.trim().isNotEmpty) {
          deviceName = remoteName.trim();
        }

        notifyListeners();
      } finally {
        _applyingRemote = false;
      }
    });
  }

  // -------------------------
  // Theme (local only)
  // -------------------------
  void toggleTheme() {
    themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    themeMode = mode;
    notifyListeners();
  }

  // -------------------------
  // Helpers: write to RTDB
  // -------------------------
  Future<void> _writeDevice(Map<String, dynamic> patch) async {
    if (_applyingRemote) return; // prevent ping-pong
    try {
      await _deviceRef.update(patch);
    } catch (_) {
      // keep UI responsive even if RTDB fails
    }
  }

  // -------------------------
  // User actions (write + log)
  // -------------------------
  Future<void> setPower(bool v) async {
    isOn = v;

    // keep your existing behavior
    if (!isOn) {
      brightness = 0;
    } else {
      if (brightness == 0) brightness = 75;
    }

    notifyListeners();

    await _writeDevice({
      'isOn': isOn,
      'brightness': brightness,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: isOn ? 'Power ON' : 'Power OFF',
    );
  }

  Future<void> setBrightness(int v) async {
    final next = v.clamp(0, 100);
    brightness = next;

    // if brightness > 0, user expects lamp "on"
    if (brightness > 0) isOn = true;

    notifyListeners();

    await _writeDevice({
      'brightness': brightness,
      'isOn': isOn,
    });

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Brightness set to $brightness%',
    );
  }

  Future<void> setMode(String v) async {
    mode = v;
    notifyListeners();

    await _writeDevice({'mode': mode});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Mode changed to $mode',
    );
  }

  Future<void> setTimer(int? minutes) async {
    timerMinutes = minutes;
    notifyListeners();

    await _writeDevice({'timerMinutes': timerMinutes});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: timerMinutes == null ? 'Timer cleared' : 'Timer set to ${timerMinutes}m',
    );
  }

  // ✅ Device name editable from UI (and saved to RTDB)
  Future<void> setDeviceName(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    if (trimmed == deviceName) return;

    deviceName = trimmed;
    notifyListeners();

    await _writeDevice({'deviceName': deviceName});

    await ActivityRTDB.add(
      deviceId: deviceId,
      action: 'Device renamed to "$deviceName"',
    );
  }

  @override
  void dispose() {
    _connSim?.cancel();
    _deviceSub?.cancel();
    super.dispose();
  }
}
